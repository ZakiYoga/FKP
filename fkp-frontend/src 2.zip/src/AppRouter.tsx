import { Routes, Route, Navigate } from 'react-router-dom'
import { ProtectedRoute } from '@/components/auth/ProtectedRoute'
import { AppLayout } from '@/components/layout/AppLayout'
import { LoginPage } from '@/pages/auth/LoginPage'
import { ChangePasswordPage } from '@/pages/auth/ChangePasswordPage'
import { DashboardPage } from '@/pages/dashboard/DashboardPage'
import { FkpListPage } from '@/pages/fkp/FkpListPage'
import { FkpCreatePage } from '@/pages/fkp/FkpCreatePage'
import { FkpDetailPage } from '@/pages/fkp/FkpDetailPage'
import { FkpEditPage } from '@/pages/fkp/FkpEditPage'
import { AreaPage } from '@/pages/areas/AreaPage'
import { DistributorPage } from '@/pages/distributors/DistributorPage'
import { OutletPage } from '@/pages/outlets/OutletPage'
import { ProductPage } from '@/pages/products/ProductPage'
import { UserPage } from '@/pages/users/UserPage'
import { HierarchyPage } from '@/pages/hierarchy/HierarchyPage'
import { NotificationPage } from '@/pages/notifications/NotificationPage'
import { NotFoundPage, ForbiddenPage } from '@/pages/ErrorPages'

export function AppRouter() {
  return (
    <Routes>
      {/* Publik */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/403" element={<ForbiddenPage />} />
      <Route path="/" element={<Navigate to="/dashboard" replace />} />

      {/* Protected */}
      <Route element={<ProtectedRoute />}>
        <Route element={<AppLayout />}>
          {/* Dashboard */}
          <Route path="/dashboard" element={<DashboardPage />} />

          {/* Auth */}
          <Route path="/change-password" element={<ChangePasswordPage />} />

          {/* FKP */}
          <Route path="/fkp" element={<FkpListPage />} />
          <Route path="/fkp/baru" element={<FkpCreatePage />} />
          <Route path="/fkp/:id" element={<FkpDetailPage />} />
          <Route path="/fkp/:id/edit" element={<FkpEditPage />} />

          {/* Master Data */}
          <Route path="/areas" element={<AreaPage />} />
          <Route path="/distributors" element={<DistributorPage />} />
          <Route path="/outlets" element={<OutletPage />} />
          <Route path="/products" element={<ProductPage />} />

          {/* Tim & Hierarki */}
          <Route path="/hierarchy" element={<HierarchyPage />} />

          {/* User Management (SuperAdmin only) */}
          <Route element={<ProtectedRoute allowedRoles={['superadmin']} />}>
            <Route
              path="/users"
              element={<UserPage />}
            />
          </Route>

          {/* Notifikasi */}
          <Route path="/notifications" element={<NotificationPage />} />
        </Route>
      </Route>

      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  )
}


function ComingSoon({ title }: { title: string }) {
  return (
    <div className="card card-body text-center py-16 animate-fade-in">
      <p className="text-4xl mb-4">🚧</p>
      <h2 className="text-xl font-semibold text-gray-900">{title}</h2>
      <p className="text-gray-400 text-sm mt-2">Halaman ini sedang dalam pengembangan.</p>
    </div>
  )
}
