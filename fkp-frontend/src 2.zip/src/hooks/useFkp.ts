import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { fkpApi } from '@/api/fkp'
import type { FkpCreatePayload } from '@/types'
import { distributorApi, outletApi, productApi } from '@/api/masterdata'
import { getErrorMessage } from '@/lib/utils'

// ── Query Keys ─────────────────────────────────────────────────────────────
export const fkpKeys = {
  all: ['fkp'] as const,
  list: (filters?: object) => [...fkpKeys.all, 'list', filters] as const,
  detail: (id: string) => [...fkpKeys.all, 'detail', id] as const,
}

// ── List & Detail ──────────────────────────────────────────────────────────
export function useFkpList(filters?: { status?: string; prioritas?: string }) {
  return useQuery({
    queryKey: fkpKeys.list(filters),
    queryFn: () => fkpApi.list(filters),
  })
}

export function useFkpDetail(id: string | undefined) {
  return useQuery({
    queryKey: fkpKeys.detail(id!),
    queryFn: () => fkpApi.detail(id!),
    enabled: !!id,
  })
}

// ── Create ────────────────────────────────────────────────────────────────
export function useCreateFkp() {
  const queryClient = useQueryClient()
  const navigate = useNavigate()

  return useMutation({
    mutationFn: (data: FkpCreatePayload) => fkpApi.create(data),
    onSuccess: (fkp) => {
      queryClient.invalidateQueries({ queryKey: fkpKeys.all })
      toast.success(`FKP ${fkp.nomor_fkp} berhasil dibuat sebagai Draft.`)
      navigate(`/fkp/${fkp.id}`)
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  })
}

export function useUpdateFkp(fkpId: string) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (data: Partial<FkpCreatePayload>) => fkpApi.update(fkpId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: fkpKeys.detail(fkpId) })
      queryClient.invalidateQueries({ queryKey: fkpKeys.all })
      toast.success('FKP berhasil diupdate.')
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  })
}

// ── Upload Attachment ─────────────────────────────────────────────────────
export function useUploadAttachment(fkpId: string) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (file: File) => fkpApi.uploadAttachment(fkpId, file),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: fkpKeys.detail(fkpId) })
      toast.success('Foto berhasil diupload.')
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  })
}

export function useDeleteAttachment(fkpId: string) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (attachmentId: string) => fkpApi.deleteAttachment(fkpId, attachmentId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: fkpKeys.detail(fkpId) })
      toast.success('Foto dihapus.')
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  })
}

// ── Submit ────────────────────────────────────────────────────────────────
export function useSubmitFkp(fkpId: string) {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: () => fkpApi.submit(fkpId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: fkpKeys.detail(fkpId) })
      queryClient.invalidateQueries({ queryKey: fkpKeys.all })
      toast.success('FKP berhasil disubmit. Menunggu review APSM.')
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  })
}

// ── Generic Status Transition ──────────────────────────────────────────────
function useStatusTransition(
  fkpId: string,
  mutationFn: () => Promise<unknown>,
  successMessage: string,
) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: fkpKeys.detail(fkpId) })
      queryClient.invalidateQueries({ queryKey: fkpKeys.all })
      toast.success(successMessage)
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  })
}

export function useApsmReview(fkpId: string, catatan?: string | null) {
  return useStatusTransition(
    fkpId,
    () => fkpApi.apsmReview(fkpId, { catatan: catatan ?? null }),
    'FKP diteruskan ke Admin HO.',
  )
}

export function useAdminApprove(fkpId: string, catatan?: string | null) {
  return useStatusTransition(
    fkpId,
    () => fkpApi.adminApprove(fkpId, { catatan_admin: catatan ?? null }),
    'FKP disetujui dan diteruskan ke QC.',
  )
}

export function useRequestRevision(fkpId: string, catatan: string) {
  return useStatusTransition(
    fkpId,
    () => fkpApi.requestRevision(fkpId, { catatan }),
    'FKP dikembalikan untuk revisi.',
  )
}

export function useStartInvestigation(fkpId: string) {
  return useStatusTransition(
    fkpId,
    () => fkpApi.startInvestigation(fkpId),
    'Investigasi dimulai.',
  )
}

export function useFinishInvestigation(
  fkpId: string,
  sumber_ketidaksesuaian: 'internal' | 'pelanggan',
  catatan?: string | null,
) {
  return useStatusTransition(
    fkpId,
    () => fkpApi.finishInvestigation(fkpId, { sumber_ketidaksesuaian, catatan: catatan ?? null }),
    'Hasil investigasi disimpan.',
  )
}

export function useRsmApprove(fkpId: string, catatan?: string | null) {
  return useStatusTransition(
    fkpId,
    () => fkpApi.rsmApprove(fkpId, { catatan: catatan ?? null }),
    'FKP disetujui RSM, diteruskan ke Direktur.',
  )
}

export function useDirekturApprove(fkpId: string, catatan?: string | null) {
  return useStatusTransition(
    fkpId,
    () => fkpApi.direkturApprove(fkpId, { catatan: catatan ?? null }),
    'FKP disetujui Direktur, menunggu keputusan final Admin HO.',
  )
}

export function useFinalDecision(fkpId: string, terima: boolean, catatan?: string | null) {
  return useStatusTransition(
    fkpId,
    () => fkpApi.finalDecision(fkpId, terima, { catatan: catatan ?? null }),
    terima ? 'FKP diterima!' : 'FKP ditolak.',
  )
}

export function useRejectFkp(fkpId: string, catatan: string) {
  return useStatusTransition(
    fkpId,
    () => fkpApi.reject(fkpId, { catatan }),
    'FKP ditolak.',
  )
}

export function useCloseFkp(fkpId: string, catatan?: string | null) {
  return useStatusTransition(
    fkpId,
    () => fkpApi.close(fkpId, { catatan: catatan ?? null }),
    'FKP berhasil ditutup.',
  )
}

// ── Master Data ────────────────────────────────────────────────────────────
export function useDistributors(params?: { area_id?: string }) {
  return useQuery({
    queryKey: ['distributors', params],
    queryFn: () => distributorApi.list(params),
    staleTime: 10 * 60 * 1000,
  })
}

export function useOutlets(distributorId?: string) {
  return useQuery({
    queryKey: ['outlets', distributorId],
    queryFn: () => outletApi.list({ distributor_id: distributorId }),
    enabled: !!distributorId,
    staleTime: 10 * 60 * 1000,
  })
}

export function useProducts() {
  return useQuery({
    queryKey: ['products', 'active'],
    queryFn: () => productApi.list({ is_active: true }),
    staleTime: 10 * 60 * 1000,
  })
}