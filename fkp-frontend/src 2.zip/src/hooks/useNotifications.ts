import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import toast from 'react-hot-toast'
import { notificationsApi } from '@/api/notifications'
import { getErrorMessage } from '@/lib/utils'

// ─── Query Keys ───────────────────────────────────────────────────────────────
export const notifKeys = {
  all:         ['notifications'] as const,
  list:        (params?: object) => [...notifKeys.all, 'list', params] as const,
  unreadCount: () => [...notifKeys.all, 'unread-count'] as const,
}

// ─── List notifikasi ──────────────────────────────────────────────────────────
export function useNotifications(params?: {
  unread_only?: boolean
  limit?: number
  offset?: number
}) {
  return useQuery({
    queryKey: notifKeys.list(params),
    queryFn: () => notificationsApi.list(params),
    staleTime: 30 * 1000, // 30 detik
  })
}

// ─── Unread count — untuk badge di navbar ────────────────────────────────────
export function useUnreadCount() {
  return useQuery({
    queryKey: notifKeys.unreadCount(),
    queryFn: notificationsApi.unreadCount,
    // Polling setiap 30 detik agar badge selalu fresh
    refetchInterval: 30 * 1000,
    staleTime: 15 * 1000,
  })
}

// ─── Tandai satu notifikasi dibaca ───────────────────────────────────────────
export function useMarkRead() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => notificationsApi.markRead([id]),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: notifKeys.all })
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  })
}

// ─── Tandai semua dibaca ──────────────────────────────────────────────────────
export function useMarkAllRead() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: notificationsApi.markAllRead,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: notifKeys.all })
      toast.success('Semua notifikasi telah dibaca.')
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  })
}

// ─── Hapus notifikasi ─────────────────────────────────────────────────────────
export function useDeleteNotification() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => notificationsApi.delete(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: notifKeys.all })
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  })
}
