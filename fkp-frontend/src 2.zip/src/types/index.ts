// ─── AUTH ─────────────────────────────────────────────────────────────────────

export interface RoleInfo {
  id: string
  kode_role: string
  nama_role: string
}

export interface UserMe {
  id: string
  nama: string
  email: string
  no_telepon: string | null
  is_active: boolean
  last_login: string | null
  created_at: string
  role: RoleInfo | null
}

export interface LoginRequest {
  email: string
  password: string
}

export interface LoginResponse {
  access_token: string
  token_type: string
  expires_in: number
  user: UserMe
}

// ─── FKP STATUS ───────────────────────────────────────────────────────────────

export type FkpStatusKey =
  | 'draft'
  | 'submitted'
  | 'apsm_review'
  | 'in_review'
  | 'need_revision'
  | 'investigation'
  | 'investigated'
  | 'rsm_review'
  | 'direktur_review'
  | 'accepted'
  | 'rejected'
  | 'resolved'
  | 'closed'

export type FkpPrioritas = 'top_urgent' | 'urgent' | 'reguler' | 'low'
export type JenisKemasan = 'zak' | 'dus' | 'renceng'
export type TipeResolusi = 'tukar_barang' | 'potong_tagihan' | 'pemusnahan'

export const FKP_STATUS_LABEL: Record<FkpStatusKey, string> = {
  draft:           'Draft',
  submitted:       'Menunggu Review APSM',
  apsm_review:     'Direview APSM',
  in_review:       'Direview Admin HO',
  need_revision:   'Perlu Revisi',
  investigation:   'Investigasi',
  investigated:    'Investigasi Selesai',
  rsm_review:      'Menunggu Persetujuan RSM',
  direktur_review: 'Menunggu Persetujuan Direktur',
  accepted:        'Diterima',
  rejected:        'Ditolak',
  resolved:        'Selesai',
  closed:          'Ditutup',
}

export const FKP_PRIORITAS_LABEL: Record<FkpPrioritas, string> = {
  top_urgent: '🔴 Top Urgent',
  urgent:     '🟠 Urgent',
  reguler:    '🟢 Reguler',
  low:        '🔵 Low',
}

// ─── AREA & WILAYAH ───────────────────────────────────────────────────────────

export interface Provinsi {
  id: number
  nama_provinsi: string
}

export interface Area {
  id: string
  kode_area: string
  nama_area: string
  pic_user_id: string | null
  status: string
  created_at: string
  updated_at: string
  provinsi: Provinsi[]
}

// ─── DISTRIBUTOR & OUTLET ─────────────────────────────────────────────────────

export interface Distributor {
  id: string
  area_id: string
  kode_distributor: string
  nama_perusahaan: string
  pemilik: string
  no_telepon: string | null
  email_perusahaan: string | null
  alamat_lengkap: string | null
  status: string
}

export interface Outlet {
  id: string
  distributor_id: string
  kode_outlet: string
  nama_toko: string
  pemilik_toko: string
  tipe_toko: string
  no_hp: string | null
  email: string | null
  alamat_lengkap: string | null
  latitude: number | null
  longitude: number | null
  foto_url: string | null
  pic_user_id: string | null
  status: string
}

// ─── PRODUCT ──────────────────────────────────────────────────────────────────

export interface Product {
  id: string
  kode_produk: string
  nama_produk: string
  jenis_kemasan: JenisKemasan
  berat_gr: number | null
  is_active: boolean
}

// ─── FKP ──────────────────────────────────────────────────────────────────────

export interface FkpAttachment {
  id: string
  fkp_id: string
  tipe_file: string
  nama_file: string
  url: string
  ukuran_bytes: number | null
  uploaded_by: string
  uploaded_at: string
}

export interface FkpStatusLog {
  id: string
  status_lama: string | null
  status_baru: string
  catatan: string | null
  changed_by: string
  changed_at: string
}

export interface FkpResolution {
  id: string
  fkp_id: string
  tipe_resolusi: TipeResolusi
  nilai_cashback: number | null
  nama_bank: string | null
  nomor_rekening: string | null
  atas_nama: string | null
  nomor_nota_retur: string | null
  nomor_do: string | null
  tanggal_pengiriman: string | null
  ekspedisi: string | null
  resi_pengiriman: string | null
  tanggal_pemusnahan: string | null
  lokasi_pemusnahan: string | null
  foto_pemusnahan: unknown | null
  keterangan: string | null
  dibuat_oleh: string
  created_at: string
}

export interface FkpDetail {
  id: string
  nomor_fkp: string
  outlet_id: string | null
  distributor_id: string
  submitted_by: string
  handled_by: string | null
  product_id: string | null
  jenis_kemasan: JenisKemasan
  qty_zak: number
  qty_dus: number
  qty_renceng: number
  batch_number: string | null
  expired_date: string | null
  jenis_keluhan: string
  deskripsi_keluhan: string
  prioritas: FkpPrioritas
  status: FkpStatusKey
  catatan_distributor: string | null
  catatan_sc_spv: string | null
  catatan_apsm: string | null
  catatan_admin: string | null
  catatan_qc: string | null
  catatan_rsm: string | null
  catatan_direktur: string | null
  sumber_ketidaksesuaian: string | null
  nomor_surat_jalan: string | null
  tanggal_pengajuan: string | null
  tanggal_selesai: string | null
  created_at: string
  updated_at: string
  status_logs: FkpStatusLog[]
  resolution: FkpResolution | null
  attachments: FkpAttachment[]
}

export interface FkpListItem {
  id: string
  nomor_fkp: string
  outlet_id: string | null
  distributor_id: string
  product_id: string | null
  jenis_keluhan: string
  jenis_kemasan: JenisKemasan
  prioritas: FkpPrioritas
  status: FkpStatusKey
  tanggal_pengajuan: string | null
  created_at: string
}

export interface FkpCreatePayload {
  distributor_id: string
  outlet_id?: string | null
  product_id?: string | null
  jenis_kemasan: string
  qty_zak: number
  qty_dus: number
  qty_renceng: number
  batch_number?: string | null
  expired_date?: string | null
  jenis_keluhan: string
  deskripsi_keluhan: string
  prioritas: string
  catatan_distributor?: string | null
}

export interface StatusTransitionPayload {
  catatan?: string | null
}

export interface InvestigasiPayload {
  sumber_ketidaksesuaian: 'internal' | 'pelanggan'
  catatan?: string | null
}

export interface ResolusiPayload {
  tipe_resolusi: string
  nilai_cashback?: number | null
  nama_bank?: string | null
  nomor_rekening?: string | null
  atas_nama?: string | null
  nomor_nota_retur?: string | null
  nomor_do?: string | null
  tanggal_pengiriman?: string | null
  ekspedisi?: string | null
  resi_pengiriman?: string | null
  tanggal_pemusnahan?: string | null
  lokasi_pemusnahan?: string | null
  keterangan?: string | null
}

// ─── API ERROR ────────────────────────────────────────────────────────────────

export interface ApiError {
  detail: string | { msg: string; type: string }[]
}


// ─── UI ────────────────────────────────────────────────────────────────
export interface HeaderProps {
  sidebarOpen: boolean
  onToggleSidebar: () => void
  pageTitle?: string
}