import axios from 'axios'

/**
 * Axios instance yang sudah dikonfigurasi untuk FKP API.
 *
 * Fitur:
 * - Base URL ke /api (di-proxy vite ke http://localhost:8000)
 * - Request interceptor: otomatis sisipkan JWT token dari localStorage
 * - Response interceptor: redirect ke /login jika 401 (token expired)
 */
const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 30000, // 30 detik
})

// ─── REQUEST INTERCEPTOR ──────────────────────────────────────────────────────
// Sisipkan token di setiap request jika ada
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('fkp_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error),
)

// ─── RESPONSE INTERCEPTOR ─────────────────────────────────────────────────────
// Handle error global
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token expired atau invalid → bersihkan storage dan redirect ke login
      localStorage.removeItem('fkp_token')
      localStorage.removeItem('fkp_user')
      // Hanya redirect jika bukan di halaman login
      if (!window.location.pathname.includes('/login')) {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  },
)

export default api
