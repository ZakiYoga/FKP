import { useParams, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useEffect, useRef, useState } from 'react'
import { ArrowLeft, Loader2, Upload, X, Trash2 } from 'lucide-react'
import toast from 'react-hot-toast'
import { useFkpDetail, useUpdateFkp, useUploadAttachment, useDeleteAttachment } from '@/hooks/useFkp'
import { useDistributors, useOutlets, useProducts } from '@/hooks/useMasterData'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { PageLoader } from '@/components/ui/Spinner'
import api from '@/lib/axios'

const schema = z.object({
  product_id: z.string().optional(),
  jenis_kemasan: z.enum(['zak', 'dus', 'renceng']),
  qty_zak: z.coerce.number().min(0),
  qty_dus: z.coerce.number().min(0),
  qty_renceng: z.coerce.number().min(0),
  batch_number: z.string().optional(),
  expired_date: z.string().optional(),
  jenis_keluhan: z.string().min(3),
  deskripsi_keluhan: z.string().min(10),
  prioritas: z.enum(['top_urgent', 'urgent', 'reguler', 'low']),
  catatan_distributor: z.string().optional(),
})
type FormData = z.infer<typeof schema>

export function FkpEditPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const fileRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)

  const { data: fkp, isLoading } = useFkpDetail(id)
  const { mutate: update, isPending: isUpdating } = useUpdateFkp(id ?? '')
  const { mutate: deleteAtt } = useDeleteAttachment(id ?? '')
  const { data: products = [] } = useProducts()

  const { register, handleSubmit, reset, watch, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
  })

  const watchKemasan = watch('jenis_kemasan')

  useEffect(() => {
    if (!fkp) return
    if (!['draft', 'need_revision'].includes(fkp.status)) {
      toast.error('FKP ini tidak bisa diedit.')
      navigate(`/fkp/${fkp.id}`)
      return
    }
    reset({
      product_id: fkp.product_id ?? '',
      jenis_kemasan: fkp.jenis_kemasan,
      qty_zak: fkp.qty_zak,
      qty_dus: fkp.qty_dus,
      qty_renceng: fkp.qty_renceng,
      batch_number: fkp.batch_number ?? '',
      expired_date: fkp.expired_date ?? '',
      jenis_keluhan: fkp.jenis_keluhan,
      deskripsi_keluhan: fkp.deskripsi_keluhan,
      prioritas: fkp.prioritas,
      catatan_distributor: fkp.catatan_distributor ?? '',
    })
  }, [fkp, reset, navigate])

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !id) return
    setUploading(true)
    try {
      const form = new FormData()
      form.append('file', file)
      await api.post(`/fkp/${id}/attachments`, form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      toast.success('Foto berhasil diupload.')
      // Refresh FKP detail
      window.location.reload()
    } catch {
      toast.error('Gagal upload foto.')
    } finally {
      setUploading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  const onSubmit = (data: FormData) => {
    update(
      {
        ...data,
        product_id: data.product_id || null,
        batch_number: data.batch_number || null,
        expired_date: data.expired_date || null,
        catatan_distributor: data.catatan_distributor || null,
      },
      { onSuccess: () => navigate(`/fkp/${id}`) },
    )
  }

  if (isLoading) return <PageLoader />
  if (!fkp) return null

  return (
    <div className="max-w-3xl mx-auto animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(`/fkp/${id}`)} className="btn-ghost btn-sm p-2">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-xl font-bold text-gray-900">Edit FKP</h1>
          <p className="text-sm text-gray-400 font-mono">{fkp.nomor_fkp}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Section 1: Detail Produk */}
        <div className="card">
          <div className="card-header">
            <h2 className="font-semibold text-gray-900">Detail Produk</h2>
          </div>
          <div className="card-body space-y-4">
            <Select label="Produk" placeholder="— Pilih produk —" {...register('product_id')}>
              {products.map((p) => (
                <option key={p.id} value={p.id}>[{p.kode_produk}] {p.nama_produk}</option>
              ))}
            </Select>
            <div className="grid grid-cols-2 gap-4">
              <Select label="Jenis Kemasan" required error={errors.jenis_kemasan?.message} {...register('jenis_kemasan')}>
                <option value="zak">Zak (10 kg)</option>
                <option value="dus">Dus (Karton)</option>
                <option value="renceng">Renceng (Sachet)</option>
              </Select>
              {watchKemasan === 'zak' && <Input label="Jumlah Zak" type="number" min={0} {...register('qty_zak')} />}
              {watchKemasan === 'dus' && <Input label="Jumlah Dus" type="number" min={0} {...register('qty_dus')} />}
              {watchKemasan === 'renceng' && <Input label="Jumlah Renceng" type="number" min={0} {...register('qty_renceng')} />}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Input label="Nomor Batch" placeholder="BT-2025-001" {...register('batch_number')} />
              <Input label="Tanggal Kadaluarsa" type="date" {...register('expired_date')} />
            </div>
          </div>
        </div>

        {/* Section 2: Detail Keluhan */}
        <div className="card">
          <div className="card-header">
            <h2 className="font-semibold text-gray-900">Detail Keluhan</h2>
          </div>
          <div className="card-body space-y-4">
            <Select label="Jenis Keluhan" required error={errors.jenis_keluhan?.message} placeholder="— Pilih —" {...register('jenis_keluhan')}>
              <option value="Produk rusak / cacat fisik">Produk rusak / cacat fisik</option>
              <option value="Kemasan bocor / sobek">Kemasan bocor / sobek</option>
              <option value="Produk terkontaminasi">Produk terkontaminasi</option>
              <option value="Produk kadaluarsa">Produk kadaluarsa</option>
              <option value="Benda asing dalam produk">Benda asing dalam produk</option>
              <option value="Kualitas tidak sesuai">Kualitas tidak sesuai standar</option>
              <option value="Kuantitas tidak sesuai">Kuantitas tidak sesuai</option>
              <option value="Lainnya">Lainnya</option>
            </Select>
            <Select label="Prioritas" required {...register('prioritas')}>
              <option value="top_urgent">🔴 Top Urgent</option>
              <option value="urgent">🟠 Urgent</option>
              <option value="reguler">🟢 Reguler</option>
              <option value="low">🔵 Low</option>
            </Select>
            <Textarea label="Deskripsi Keluhan" required rows={5} error={errors.deskripsi_keluhan?.message} {...register('deskripsi_keluhan')} />
            <Textarea label="Catatan Tambahan" rows={3} {...register('catatan_distributor')} />
          </div>
        </div>

        {/* Section 3: Foto Bukti */}
        <div className="card">
          <div className="card-header flex items-center justify-between">
            <h2 className="font-semibold text-gray-900">Foto Bukti</h2>
            <span className="text-xs text-gray-400">{fkp.attachments.length} foto</span>
          </div>
          <div className="card-body">
            {fkp.attachments.length > 0 && (
              <div className="grid grid-cols-4 gap-3 mb-4">
                {fkp.attachments.map((att) => (
                  <div key={att.id} className="relative group aspect-square">
                    <img src={att.url} alt={att.nama_file} className="w-full h-full object-cover rounded-lg border border-gray-200" />
                    <button
                      type="button"
                      onClick={() => deleteAtt(att.id)}
                      className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full
                                 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
            <input ref={fileRef} type="file" accept="image/*,video/mp4" onChange={handleFileUpload} className="hidden" />
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
              className="w-full border-2 border-dashed border-gray-200 rounded-xl py-6 flex flex-col
                         items-center gap-2 text-gray-400 hover:border-brand-400 hover:text-brand-500
                         hover:bg-brand-50 transition-all cursor-pointer disabled:opacity-50"
            >
              {uploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Upload className="w-5 h-5" />}
              <span className="text-sm">{uploading ? 'Mengupload...' : 'Tambah Foto'}</span>
            </button>
          </div>
        </div>

        <div className="flex justify-between pb-8">
          <button type="button" onClick={() => navigate(`/fkp/${id}`)} className="btn-secondary">Batal</button>
          <button type="submit" disabled={isUpdating} className="btn-primary">
            {isUpdating ? <><Loader2 className="w-4 h-4 animate-spin" /> Menyimpan...</> : 'Simpan Perubahan'}
          </button>
        </div>
      </form>
    </div>
  )
}
