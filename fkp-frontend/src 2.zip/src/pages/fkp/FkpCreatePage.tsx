import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useNavigate } from 'react-router-dom'
import { Loader2, ArrowLeft, Upload, X, ImageIcon, AlertCircle, Info } from 'lucide-react'
import { useState, useRef, useEffect } from 'react'
import { useCreateFkp, useDistributors, useOutlets, useProducts } from '@/hooks/useFkp'
import { useUploadAttachment } from '@/hooks/useFkp'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { useKodeRole } from '@/store/authStore'
import toast from 'react-hot-toast'

const schema = z.object({
  distributor_id: z.string().min(1, 'Distributor wajib dipilih'),
  outlet_id: z.string().optional(),
  product_id: z.string().optional(),
  jenis_kemasan: z.enum(['zak', 'dus', 'renceng'], {
    errorMap: () => ({ message: 'Jenis kemasan wajib dipilih' }),
  }),
  qty_zak: z.coerce.number().min(0),
  qty_dus: z.coerce.number().min(0),
  qty_renceng: z.coerce.number().min(0),
  batch_number: z.string().optional(),
  expired_date: z.string().optional(),
  jenis_keluhan: z.string().min(3, 'Jenis keluhan wajib diisi'),
  deskripsi_keluhan: z.string().min(10, 'Deskripsi minimal 10 karakter'),
  prioritas: z.enum(['top_urgent', 'urgent', 'reguler', 'low']),
  catatan_distributor: z.string().optional(),
})

type FormData = z.infer<typeof schema>

export function FkpCreatePage() {
  const navigate = useNavigate()
  const kodeRole = useKodeRole()
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
  const [previews, setPreviews] = useState<string[]>([])
  const [createdFkpId, setCreatedFkpId] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const { mutateAsync: createFkp, isPending: isCreating } = useCreateFkp()
  const { mutateAsync: uploadFile, isPending: isUploading } = useUploadAttachment(createdFkpId ?? '')

  // ── Role flags ──────────────────────────────────────────────────────────────
  const isOutlet      = kodeRole === 'outlet'
  const isDistributor = kodeRole === 'distributor'
  const isScSpv       = kodeRole === 'sc_spv'
  const isApsm        = kodeRole === 'apsm'

  // Semua role di atas mendapat list distributor dari backend (sudah difilter per role)
  const { data: distributors = [], isLoading: loadingDist } = useDistributors()
  const { data: products = [], isLoading: loadingProd } = useProducts()

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { prioritas: 'reguler', qty_zak: 0, qty_dus: 0, qty_renceng: 0 },
  })

  const watchDistributor = watch('distributor_id')

  // ── Auto-select: jika hanya 1 distributor tersedia (outlet / distributor role) ──
  useEffect(() => {
    if (distributors.length === 1 && !watchDistributor) {
      setValue('distributor_id', distributors[0].id, { shouldValidate: true })
    }
  }, [distributors, watchDistributor, setValue])

  const { data: outlets = [], isLoading: loadingOutlets } = useOutlets(watchDistributor)

  // ── Auto-select: jika outlet login dan hanya 1 outlet (diri sendiri) ───────
  const watchOutlet = watch('outlet_id')
  useEffect(() => {
    if (isOutlet && outlets.length === 1 && !watchOutlet) {
      setValue('outlet_id', outlets[0].id, { shouldValidate: true })
    }
  }, [isOutlet, outlets, watchOutlet, setValue])

  const watchKemasan = watch('jenis_kemasan')

  const handleFileAdd = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? [])
    if (uploadedFiles.length + files.length > 5) {
      toast.error('Maksimal 5 foto.')
      return
    }
    setUploadedFiles((prev) => [...prev, ...files])
    files.forEach((f) => {
      const url = URL.createObjectURL(f)
      setPreviews((prev) => [...prev, url])
    })
    if (fileRef.current) fileRef.current.value = ''
  }

  const removeFile = (idx: number) => {
    setUploadedFiles((prev) => prev.filter((_, i) => i !== idx))
    setPreviews((prev) => {
      URL.revokeObjectURL(prev[idx])
      return prev.filter((_, i) => i !== idx)
    })
  }

  const onSubmit = async (data: FormData) => {
    if (uploadedFiles.length === 0) {
      toast.error('Minimal 1 foto bukti wajib diupload.')
      return
    }

    try {
      const fkp = await createFkp({
        ...data,
        outlet_id: data.outlet_id || null,
        product_id: data.product_id || null,
        batch_number: data.batch_number || null,
        expired_date: data.expired_date || null,
        catatan_distributor: data.catatan_distributor || null,
      })

      setCreatedFkpId(fkp.id)

      for (const file of uploadedFiles) {
        await fkpApi_uploadSingleFile(fkp.id, file)
      }

      toast.success(`FKP ${fkp.nomor_fkp} berhasil dibuat. Silakan submit untuk diteruskan.`)
      navigate(`/fkp/${fkp.id}`)
    } catch {
      // Error sudah di-handle oleh mutation onError
    }
  }

  const fkpApi_uploadSingleFile = async (fkpId: string, file: File) => {
    const form = new FormData()
    form.append('file', file)
    const { default: api } = await import('@/lib/axios')
    await api.post(`/fkp/${fkpId}/attachments`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
  }

  const isPending = isCreating || isUploading

  // ── Kondisi: outlet belum terdaftar di distributor manapun ─────────────────
  const outletBelumTerdaftar = isOutlet && !loadingDist && distributors.length === 0

  return (
    <div className="max-w-3xl mx-auto animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={() => navigate('/fkp')}
          className="btn-ghost btn-sm p-2"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-xl font-bold text-gray-900">Buat FKP Baru</h1>
          <p className="text-sm text-gray-500">Isi semua data keluhan produk dengan lengkap</p>
        </div>
      </div>

      {/* ── Banner: outlet belum terdaftar ──────────────────────────────────── */}
      {outletBelumTerdaftar && (
        <div className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200 rounded-xl mb-6">
          <Info className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-amber-800">Outlet belum terdaftar di distributor</p>
            <p className="text-sm text-amber-700 mt-0.5">
              Akun outlet Anda belum tercantum di distributor manapun.
              Hubungi admin atau APSM untuk mendaftarkan outlet Anda ke distributor yang sesuai.
            </p>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">

        {/* ── Section 1: Identitas ─────────────────────────── */}
        <div className="card">
          <div className="card-header">
            <h2 className="font-semibold text-gray-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-brand-600 text-white text-xs flex items-center justify-center font-bold">1</span>
              Identitas Keluhan
            </h2>
          </div>
          <div className="card-body space-y-4">

            {/* ── Distributor Field ──────────────────────────────────────────── */}
            {/* outlet: auto-filled, tampilkan read-only jika sudah ada */}
            {/* 
              Semua role pakai Select yang sama — setValue di useEffect yang mengontrol
              nilai untuk role outlet/distributor (auto-select jika hanya 1 pilihan).
              Hidden input + {...register()} TIDAK dipakai karena konflik dengan RHF:
              value prop tidak dikenali pada uncontrolled input milik RHF.
            */}
            {outletBelumTerdaftar ? null : (
              <div>
                <Select
                  label="Distributor"
                  required
                  placeholder={loadingDist ? 'Memuat...' : '— Pilih distributor —'}
                  error={errors.distributor_id?.message}
                  disabled={(isOutlet || isDistributor) && distributors.length === 1}
                  {...register('distributor_id')}
                >
                  {distributors.map((d) => (
                    <option key={d.id} value={d.id}>
                      [{d.kode_distributor}] {d.nama_perusahaan}
                    </option>
                  ))}
                </Select>
                {(isOutlet || isDistributor) && distributors.length === 1 && (
                  <p className="text-xs text-gray-400 mt-1">
                    {isOutlet ? 'Outlet Anda terdaftar di distributor ini.' : 'Distributor Anda.'}
                  </p>
                )}
              </div>
            )}

            {/* ── Outlet Field ───────────────────────────────────────────────── */}
            {watchDistributor && (
              isOutlet ? (
                outlets.length === 1 ? (
                  <div>
                    <Select
                      label="Outlet"
                      disabled
                      {...register('outlet_id')}
                    >
                      <option value={outlets[0].id}>
                        [{outlets[0].kode_outlet}] {outlets[0].nama_toko}
                      </option>
                    </Select>
                    <p className="text-xs text-gray-400 mt-1">Keluhan ini akan tercatat atas nama outlet Anda.</p>
                  </div>
                ) : null
              ) : (
                /* role lain: dropdown outlet (opsional) */
                outlets.length > 0 ? (
                  <Select
                    label={`Outlet (opsional)${loadingOutlets ? ' — Memuat...' : ''}`}
                    placeholder="— Keluhan dari outlet tertentu? —"
                    {...register('outlet_id')}
                  >
                    {outlets.map((o) => (
                      <option key={o.id} value={o.id}>
                        [{o.kode_outlet}] {o.nama_toko}
                      </option>
                    ))}
                  </Select>
                ) : watchDistributor && !loadingOutlets ? (
                  <p className="text-xs text-gray-400 italic">
                    Tidak ada outlet terdaftar di distributor ini.
                  </p>
                ) : null
              )
            )}

            {/* Produk */}
            <Select
              label="Produk (opsional)"
              placeholder={loadingProd ? 'Memuat...' : '— Pilih produk —'}
              {...register('product_id')}
            >
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  [{p.kode_produk}] {p.nama_produk} — {p.jenis_kemasan}
                </option>
              ))}
            </Select>

            {/* Prioritas */}
            <Select
              label="Prioritas"
              required
              error={errors.prioritas?.message}
              {...register('prioritas')}
            >
              <option value="top_urgent">🔴 Top Urgent</option>
              <option value="urgent">🟠 Urgent</option>
              <option value="reguler">🟢 Reguler</option>
              <option value="low">🔵 Low</option>
            </Select>
          </div>
        </div>

        {/* ── Section 2: Detail Produk ─────────────────────── */}
        <div className="card">
          <div className="card-header">
            <h2 className="font-semibold text-gray-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-brand-600 text-white text-xs flex items-center justify-center font-bold">2</span>
              Detail Produk
            </h2>
          </div>
          <div className="card-body space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Select
                label="Jenis Kemasan"
                required
                placeholder="— Pilih kemasan —"
                error={errors.jenis_kemasan?.message}
                {...register('jenis_kemasan')}
              >
                <option value="zak">Zak (10 kg)</option>
                <option value="dus">Dus (Karton)</option>
                <option value="renceng">Renceng (Sachet)</option>
              </Select>

              {watchKemasan === 'zak' && (
                <Input
                  label="Jumlah Zak"
                  type="number"
                  min={0}
                  error={errors.qty_zak?.message}
                  {...register('qty_zak')}
                />
              )}
              {watchKemasan === 'dus' && (
                <Input
                  label="Jumlah Dus"
                  type="number"
                  min={0}
                  error={errors.qty_dus?.message}
                  {...register('qty_dus')}
                />
              )}
              {watchKemasan === 'renceng' && (
                <Input
                  label="Jumlah Renceng"
                  type="number"
                  min={0}
                  error={errors.qty_renceng?.message}
                  {...register('qty_renceng')}
                />
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Nomor Batch"
                placeholder="Contoh: BT-2025-001"
                {...register('batch_number')}
              />
              <Input
                label="Tanggal Kadaluarsa"
                type="date"
                {...register('expired_date')}
              />
            </div>
          </div>
        </div>

        {/* ── Section 3: Detail Keluhan ────────────────────── */}
        <div className="card">
          <div className="card-header">
            <h2 className="font-semibold text-gray-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-brand-600 text-white text-xs flex items-center justify-center font-bold">3</span>
              Detail Keluhan
            </h2>
          </div>
          <div className="card-body space-y-4">
            <Select
              label="Jenis Keluhan"
              required
              placeholder="— Pilih jenis keluhan —"
              error={errors.jenis_keluhan?.message}
              {...register('jenis_keluhan')}
            >
              <option value="Produk rusak / cacat fisik">Produk rusak / cacat fisik</option>
              <option value="Kemasan bocor / sobek">Kemasan bocor / sobek</option>
              <option value="Produk terkontaminasi">Produk terkontaminasi</option>
              <option value="Produk kadaluarsa">Produk kadaluarsa</option>
              <option value="Benda asing dalam produk">Benda asing dalam produk</option>
              <option value="Kualitas tidak sesuai">Kualitas tidak sesuai standar</option>
              <option value="Kuantitas tidak sesuai">Kuantitas tidak sesuai</option>
              <option value="Lainnya">Lainnya</option>
            </Select>

            <Textarea
              label="Deskripsi Keluhan"
              required
              placeholder="Jelaskan keluhan secara detail: kondisi produk, kapan ditemukan, dampak yang terjadi..."
              rows={5}
              error={errors.deskripsi_keluhan?.message}
              {...register('deskripsi_keluhan')}
            />

            <Textarea
              label="Catatan Tambahan (opsional)"
              placeholder="Catatan internal, kondisi penyimpanan, atau informasi lain yang relevan..."
              rows={3}
              {...register('catatan_distributor')}
            />
          </div>
        </div>

        {/* ── Section 4: Upload Foto ───────────────────────── */}
        <div className="card">
          <div className="card-header">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-gray-900 flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-brand-600 text-white text-xs flex items-center justify-center font-bold">4</span>
                Foto Bukti
              </h2>
              <span className="text-xs text-gray-400">{uploadedFiles.length}/5 foto</span>
            </div>
          </div>
          <div className="card-body">
            <div className="flex items-start gap-2 p-3 bg-amber-50 rounded-lg border border-amber-200 mb-4">
              <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <p className="text-xs text-amber-700">
                Minimal 1 foto wajib diupload sebelum FKP bisa disubmit.
                Foto akan diupload setelah data keluhan tersimpan.
              </p>
            </div>

            {previews.length > 0 && (
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-3 mb-4">
                {previews.map((url, idx) => (
                  <div key={idx} className="relative group aspect-square">
                    <img
                      src={url}
                      alt={`Preview ${idx + 1}`}
                      className="w-full h-full object-cover rounded-lg border border-gray-200"
                    />
                    <button
                      type="button"
                      onClick={() => removeFile(idx)}
                      className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white
                                 rounded-full flex items-center justify-center
                                 opacity-0 group-hover:opacity-100 transition-opacity
                                 hover:bg-red-600 shadow-sm"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {uploadedFiles.length < 5 && (
              <>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp,video/mp4"
                  multiple
                  onChange={handleFileAdd}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="w-full border-2 border-dashed border-gray-200 rounded-xl
                             py-8 flex flex-col items-center gap-2 text-gray-400
                             hover:border-brand-400 hover:text-brand-500 hover:bg-brand-50
                             transition-all duration-200 cursor-pointer"
                >
                  <Upload className="w-6 h-6" />
                  <span className="text-sm font-medium">Klik untuk pilih foto</span>
                  <span className="text-xs">JPG, PNG, WebP, MP4 • Maks. 10MB per file</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* ── Actions ─────────────────────────────────────── */}
        <div className="flex items-center justify-between gap-3 pb-8">
          <button
            type="button"
            onClick={() => navigate('/fkp')}
            className="btn-secondary"
            disabled={isPending}
          >
            Batal
          </button>
          <button
            type="submit"
            disabled={isPending || outletBelumTerdaftar}
            className="btn-primary btn-lg"
          >
            {isPending ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                {isCreating ? 'Menyimpan FKP...' : 'Mengupload foto...'}
              </>
            ) : (
              <>
                <ImageIcon className="w-4 h-4" />
                Simpan sebagai Draft
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  )
}