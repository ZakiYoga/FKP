import { useParams, useNavigate } from 'react-router-dom'
import {
  ArrowLeft, FileText, Clock, CheckCircle2, Loader2, Send,
  AlertTriangle, ShieldCheck, XCircle, Edit2,
} from 'lucide-react'
import { useState } from 'react'
import {
  useFkpDetail,
  useSubmitFkp,
} from '@/hooks/useFkp'
import { StatusBadge, PriorittasBadge } from '@/components/ui/Badge'
import { PageLoader } from '@/components/ui/Spinner'
import { Modal } from '@/components/ui/Modal'
import { Textarea } from '@/components/ui/Textarea'
import { Select } from '@/components/ui/Select'
import { Input } from '@/components/ui/Input'
import { formatDateTime, formatDate, formatRupiah } from '@/lib/utils'
import { useKodeRole } from '@/store/authStore'
import { FKP_STATUS_LABEL } from '@/types'
import type { FkpStatusKey } from '@/types'
import { fkpApi } from '@/api/fkp'
import { useQueryClient } from '@tanstack/react-query'
import { fkpKeys } from '@/hooks/useFkp'
import toast from 'react-hot-toast'

// ─── Tipe modal aksi ──────────────────────────────────────────────────────────
type ModalTipe =
  | 'apsm_review'
  | 'admin_approve'
  | 'revision'
  | 'investigate'
  | 'finish_investigation'
  | 'rsm_approve'
  | 'direktur_approve'
  | 'final_accept'
  | 'final_reject'
  | 'reject'
  | 'close'
  | 'resolusi'

export function FkpDetailPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const kodeRole = useKodeRole()
  const queryClient = useQueryClient()

  const { data: fkp, isLoading, isError } = useFkpDetail(id)

  // ── State modal ───────────────────────────────────────────────────────────
  const [modal, setModal] = useState<ModalTipe | null>(null)
  const [catatan, setCatatan] = useState('')
  const [isConfirming, setIsConfirming] = useState(false)

  // State khusus finish_investigation
  const [sumber, setSumber] = useState<'internal' | 'pelanggan'>('internal')

  // State khusus resolusi
  const [tipeResolusi, setTipeResolusi] = useState('tukar_barang')
  const [resolusiData, setResolusiData] = useState({
    nilai_cashback: '',
    nama_bank: '',
    nomor_rekening: '',
    atas_nama: '',
    nomor_nota_retur: '',
    nomor_do: '',
    ekspedisi: '',
    resi_pengiriman: '',
    tanggal_pemusnahan: '',
    lokasi_pemusnahan: '',
    keterangan: '',
  })

  // ── Mutations ─────────────────────────────────────────────────────────────
  const { mutate: submit, isPending: isSubmitting } = useSubmitFkp(id ?? '')

  const closeModal = () => {
    setModal(null)
    setCatatan('')
    setSumber('internal')
  }

  const runAction = async (fn: () => Promise<unknown>) => {
    setIsConfirming(true)
    try {
      await fn()
      queryClient.invalidateQueries({ queryKey: fkpKeys.detail(id!) })
      queryClient.invalidateQueries({ queryKey: fkpKeys.all })
      closeModal()
      toast.success('Aksi berhasil dilakukan.')
    } catch (e: any) {
      toast.error(e?.response?.data?.detail ?? 'Terjadi kesalahan.')
    } finally {
      setIsConfirming(false)
    }
  }

  // ── Handler konfirmasi modal ──────────────────────────────────────────────
  const handleConfirm = () => {
    if (!id) return

    switch (modal) {
      case 'apsm_review':
        return runAction(() => fkpApi.apsmReview(id, { catatan: catatan || null }))

      case 'admin_approve':
        return runAction(() => fkpApi.adminApprove(id, { catatan_admin: catatan || null }))

      case 'revision':
        if (!catatan.trim()) { toast.error('Catatan alasan revisi wajib diisi.'); return }
        return runAction(() => fkpApi.requestRevision(id, { catatan }))

      case 'investigate':
        return runAction(() => fkpApi.startInvestigation(id))

      case 'finish_investigation':
        // FIX: field sumber_ketidaksesuaian (bukan sumber), catatan (bukan catatan_qc)
        return runAction(() => fkpApi.finishInvestigation(id, {
          sumber_ketidaksesuaian: sumber,
          catatan: catatan || null,
        }))

      case 'rsm_approve':
        return runAction(() => fkpApi.rsmApprove(id, { catatan: catatan || null }))

      case 'direktur_approve':
        return runAction(() => fkpApi.direkturApprove(id, { catatan: catatan || null }))

      case 'final_accept':
        // FIX: terima adalah query param (arg ke-2), catatan di body (arg ke-3)
        return runAction(() => fkpApi.finalDecision(id, true, { catatan: catatan || null }))

      case 'final_reject':
        if (!catatan.trim()) { toast.error('Alasan penolakan wajib diisi.'); return }
        // FIX: terima adalah query param (arg ke-2), catatan di body (arg ke-3)
        return runAction(() => fkpApi.finalDecision(id, false, { catatan }))

      case 'reject':
        if (!catatan.trim()) { toast.error('Alasan penolakan wajib diisi.'); return }
        return runAction(() => fkpApi.reject(id, { catatan }))

      case 'close':
        return runAction(() => fkpApi.close(id, { catatan: catatan || null }))

      case 'resolusi':
        return runAction(() => fkpApi.createResolusi(id, {
          tipe_resolusi: tipeResolusi,
          keterangan: resolusiData.keterangan || null,
          nilai_cashback: resolusiData.nilai_cashback ? Number(resolusiData.nilai_cashback) : null,
          nama_bank: resolusiData.nama_bank || null,
          nomor_rekening: resolusiData.nomor_rekening || null,
          atas_nama: resolusiData.atas_nama || null,
          nomor_nota_retur: resolusiData.nomor_nota_retur || null,
          nomor_do: resolusiData.nomor_do || null,
          ekspedisi: resolusiData.ekspedisi || null,
          resi_pengiriman: resolusiData.resi_pengiriman || null,
          tanggal_pemusnahan: resolusiData.tanggal_pemusnahan || null,
          lokasi_pemusnahan: resolusiData.lokasi_pemusnahan || null,
        }))
    }
  }

  // ── Render states ─────────────────────────────────────────────────────────
  if (isLoading) return <PageLoader />
  if (isError || !fkp) {
    return (
      <div className="card card-body text-center py-12">
        <p className="text-red-500 font-medium">FKP tidak ditemukan.</p>
        <button onClick={() => navigate('/fkp')} className="btn-secondary mt-4 mx-auto">
          <ArrowLeft className="w-4 h-4" /> Kembali
        </button>
      </div>
    )
  }

  const canEdit = fkp.status === 'draft' || fkp.status === 'need_revision'
  const canSubmit = canEdit

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">

      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/fkp')} className="btn-ghost btn-sm p-2">
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <p className="text-xs font-mono text-gray-400">{fkp.nomor_fkp}</p>
            <h1 className="text-xl font-bold text-gray-900 mt-0.5">{fkp.jenis_keluhan}</h1>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <PriorittasBadge prioritas={fkp.prioritas} />
          <StatusBadge status={fkp.status} />
        </div>
      </div>

      {/* ── Banner need_revision ──────────────────────────────────────────── */}
      {fkp.status === 'need_revision' && (
        <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-xl">
          <AlertTriangle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-red-800">FKP Perlu Diperbaiki</p>
            <p className="text-sm text-red-700 mt-0.5">
              FKP ini dikembalikan untuk revisi. Periksa catatan di bawah, perbaiki data, lalu submit kembali.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* ── Kolom kiri: Detail ──────────────────────────────────────────── */}
        <div className="lg:col-span-2 space-y-5">

          {/* Detail keluhan */}
          <div className="card">
            <div className="card-header">
              <h2 className="font-semibold text-gray-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-brand-500" /> Detail Keluhan
              </h2>
            </div>
            <div className="card-body">
              <dl className="grid grid-cols-2 gap-x-6 gap-y-4 text-sm">
                <InfoRow label="Jenis Keluhan" value={fkp.jenis_keluhan} />
                <InfoRow label="Jenis Kemasan" value={fkp.jenis_kemasan} className="capitalize" />
                {fkp.qty_zak > 0 && <InfoRow label="Jumlah Zak" value={`${fkp.qty_zak} zak`} />}
                {fkp.qty_dus > 0 && <InfoRow label="Jumlah Dus" value={`${fkp.qty_dus} dus`} />}
                {fkp.qty_renceng > 0 && <InfoRow label="Jumlah Renceng" value={`${fkp.qty_renceng} renceng`} />}
                {fkp.batch_number && <InfoRow label="Nomor Batch" value={fkp.batch_number} mono />}
                {fkp.expired_date && <InfoRow label="Kadaluarsa" value={formatDate(fkp.expired_date)} />}
                {fkp.tanggal_pengajuan && <InfoRow label="Tgl Pengajuan" value={formatDateTime(fkp.tanggal_pengajuan)} />}
                {fkp.tanggal_selesai && <InfoRow label="Tgl Selesai" value={formatDateTime(fkp.tanggal_selesai)} />}
              </dl>
              <div className="mt-4 pt-4 border-t border-gray-50">
                <p className="text-xs font-medium text-gray-500 mb-1.5">Deskripsi Keluhan</p>
                <p className="text-sm text-gray-800 leading-relaxed whitespace-pre-wrap">
                  {fkp.deskripsi_keluhan}
                </p>
              </div>
              {fkp.sumber_ketidaksesuaian && (
                <div className="mt-3 p-3 rounded-lg bg-gray-50 border border-gray-100">
                  <p className="text-xs font-medium text-gray-500">Hasil Investigasi</p>
                  <p className="text-sm font-semibold mt-0.5">
                    Sumber: {fkp.sumber_ketidaksesuaian === 'internal'
                      ? '✅ Internal (produk kami)'
                      : '❌ Pelanggan (bukan cacat produksi)'}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Catatan per role */}
          {(fkp.catatan_distributor || fkp.catatan_sc_spv || fkp.catatan_apsm ||
            fkp.catatan_admin || fkp.catatan_qc || fkp.catatan_rsm || fkp.catatan_direktur) && (
            <div className="card">
              <div className="card-header">
                <h2 className="font-semibold text-gray-900">Catatan</h2>
              </div>
              <div className="card-body space-y-3">
                <CatatanItem label="Distributor / Outlet" value={fkp.catatan_distributor} />
                <CatatanItem label="SC / SPV" value={fkp.catatan_sc_spv} />
                <CatatanItem label="APSM" value={fkp.catatan_apsm} />
                <CatatanItem label="Admin HO" value={fkp.catatan_admin} />
                <CatatanItem label="QC" value={fkp.catatan_qc} />
                <CatatanItem label="RSM" value={fkp.catatan_rsm} />
                <CatatanItem label="Direktur" value={fkp.catatan_direktur} />
              </div>
            </div>
          )}

          {/* Foto bukti */}
          {fkp.attachments.length > 0 && (
            <div className="card">
              <div className="card-header">
                <h2 className="font-semibold text-gray-900">
                  Foto Bukti ({fkp.attachments.length})
                </h2>
              </div>
              <div className="card-body">
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                  {fkp.attachments.map((att) => (
                    <a key={att.id} href={att.url} target="_blank" rel="noreferrer"
                      className="aspect-square block">
                      <img src={att.url} alt={att.nama_file}
                        className="w-full h-full object-cover rounded-lg border border-gray-200 hover:opacity-90 transition-opacity" />
                    </a>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Resolusi */}
          {fkp.resolution && (
            <div className="card">
              <div className="card-header">
                <h2 className="font-semibold text-gray-900 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-500" /> Resolusi
                </h2>
              </div>
              <div className="card-body">
                <dl className="grid grid-cols-2 gap-x-6 gap-y-3 text-sm">
                  <InfoRow label="Tipe" value={fkp.resolution.tipe_resolusi} className="capitalize" />
                  {fkp.resolution.nilai_cashback && (
                    <InfoRow label="Nilai Cashback" value={formatRupiah(fkp.resolution.nilai_cashback)} />
                  )}
                  {fkp.resolution.nama_bank && <InfoRow label="Bank" value={fkp.resolution.nama_bank} />}
                  {fkp.resolution.nomor_rekening && (
                    <InfoRow label="No. Rekening" value={fkp.resolution.nomor_rekening} mono />
                  )}
                  {fkp.resolution.atas_nama && <InfoRow label="Atas Nama" value={fkp.resolution.atas_nama} />}
                  {fkp.resolution.nomor_do && <InfoRow label="Nomor DO" value={fkp.resolution.nomor_do} mono />}
                  {fkp.resolution.ekspedisi && <InfoRow label="Ekspedisi" value={fkp.resolution.ekspedisi} />}
                  {fkp.resolution.resi_pengiriman && (
                    <InfoRow label="Resi" value={fkp.resolution.resi_pengiriman} mono />
                  )}
                  {fkp.resolution.lokasi_pemusnahan && (
                    <InfoRow label="Lokasi Pemusnahan" value={fkp.resolution.lokasi_pemusnahan} />
                  )}
                  {fkp.resolution.keterangan && (
                    <div className="col-span-2">
                      <p className="text-xs font-medium text-gray-500 mb-1">Keterangan</p>
                      <p className="text-sm text-gray-800">{fkp.resolution.keterangan}</p>
                    </div>
                  )}
                </dl>
              </div>
            </div>
          )}
        </div>

        {/* ── Kolom kanan: Aksi + History ─────────────────────────────────── */}
        <div className="space-y-5">

          {/* Panel Aksi */}
          <div className="card">
            <div className="card-header">
              <h2 className="font-semibold text-gray-900">Aksi</h2>
            </div>
            <div className="card-body space-y-2">

              {/* Edit — draft atau need_revision */}
              {canEdit && (
                <button onClick={() => navigate(`/fkp/${fkp.id}/edit`)}
                  className="btn-secondary w-full">
                  <Edit2 className="w-4 h-4" /> Edit FKP
                </button>
              )}

              {/* Submit — draft atau need_revision */}
              {canSubmit && (
                <button onClick={() => submit()} disabled={isSubmitting} className="btn-primary w-full">
                  {isSubmitting
                    ? <><Loader2 className="w-4 h-4 animate-spin" /> Memproses...</>
                    : <><Send className="w-4 h-4" /> Submit FKP</>}
                </button>
              )}

              {/* APSM: submitted → apsm_review */}
              {fkp.status === 'submitted' && kodeRole === 'apsm' && (
                <>
                  <button className="btn-primary w-full" onClick={() => setModal('apsm_review')}>
                    <ShieldCheck className="w-4 h-4" /> Review & Teruskan ke HO
                  </button>
                  <button className="btn-danger w-full" onClick={() => setModal('revision')}>
                    <AlertTriangle className="w-4 h-4" /> Minta Revisi
                  </button>
                </>
              )}

              {/* Admin HO: apsm_review → in_review */}
              {fkp.status === 'apsm_review' && kodeRole === 'admin_ho' && (
                <>
                  <button className="btn-primary w-full" onClick={() => setModal('admin_approve')}>
                    <ShieldCheck className="w-4 h-4" /> ACC & Teruskan ke QC
                  </button>
                  <button className="btn-danger w-full" onClick={() => setModal('revision')}>
                    <AlertTriangle className="w-4 h-4" /> Minta Revisi
                  </button>
                </>
              )}

              {/* QC: in_review → investigation */}
              {fkp.status === 'in_review' && kodeRole === 'qc' && (
                <>
                  <button className="btn-primary w-full" onClick={() => setModal('investigate')}>
                    Mulai Investigasi
                  </button>
                  <button className="btn-danger w-full" onClick={() => setModal('revision')}>
                    <AlertTriangle className="w-4 h-4" /> Minta Revisi
                  </button>
                </>
              )}

              {/* QC: investigation → investigated */}
              {fkp.status === 'investigation' && kodeRole === 'qc' && (
                <button className="btn-primary w-full" onClick={() => setModal('finish_investigation')}>
                  <CheckCircle2 className="w-4 h-4" /> Selesaikan Investigasi
                </button>
              )}

              {/* RSM: investigated → rsm_review */}
              {fkp.status === 'investigated' && kodeRole === 'rsm' && (
                <>
                  <button className="btn-primary w-full" onClick={() => setModal('rsm_approve')}>
                    <ShieldCheck className="w-4 h-4" /> Approve & Teruskan ke Direktur
                  </button>
                  <button className="btn-danger w-full" onClick={() => setModal('reject')}>
                    <XCircle className="w-4 h-4" /> Tolak FKP
                  </button>
                </>
              )}

              {/* Direktur: rsm_review → direktur_review */}
              {fkp.status === 'rsm_review' && kodeRole === 'direktur' && (
                <>
                  <button className="btn-primary w-full" onClick={() => setModal('direktur_approve')}>
                    <ShieldCheck className="w-4 h-4" /> Approve & Teruskan ke Admin HO
                  </button>
                  <button className="btn-danger w-full" onClick={() => setModal('reject')}>
                    <XCircle className="w-4 h-4" /> Tolak FKP
                  </button>
                </>
              )}

              {/* Admin HO: direktur_review → accepted / rejected */}
              {fkp.status === 'direktur_review' && kodeRole === 'admin_ho' && (
                <>
                  <button className="btn-primary w-full" onClick={() => setModal('final_accept')}>
                    <CheckCircle2 className="w-4 h-4" /> Terima FKP
                  </button>
                  <button className="btn-danger w-full" onClick={() => setModal('final_reject')}>
                    <XCircle className="w-4 h-4" /> Tolak FKP
                  </button>
                </>
              )}

              {/* QC / Admin HO: accepted → buat resolusi */}
              {fkp.status === 'accepted' && (kodeRole === 'qc' || kodeRole === 'admin_ho') && !fkp.resolution && (
                <button className="btn-primary w-full" onClick={() => setModal('resolusi')}>
                  <FileText className="w-4 h-4" /> Buat Resolusi
                </button>
              )}

              {/* Admin HO: resolved → closed */}
              {fkp.status === 'resolved' && kodeRole === 'admin_ho' && (
                <button className="btn-secondary w-full" onClick={() => setModal('close')}>
                  Tutup FKP
                </button>
              )}

              {/* Reject global dari Admin HO */}
              {['in_review', 'investigation', 'investigated'].includes(fkp.status)
                && kodeRole === 'admin_ho' && (
                <button className="btn-danger w-full" onClick={() => setModal('reject')}>
                  <XCircle className="w-4 h-4" /> Tolak FKP
                </button>
              )}

              {/* Tidak ada aksi */}
              {!canEdit && !canSubmit
                && !(['submitted', 'apsm_review', 'in_review', 'investigation',
                  'investigated', 'rsm_review', 'direktur_review', 'accepted', 'resolved']
                  .includes(fkp.status))
                && (
                <p className="text-sm text-gray-400 text-center py-2">
                  Tidak ada aksi tersedia.
                </p>
              )}
            </div>
          </div>

          {/* Riwayat Status */}
          <div className="card">
            <div className="card-header">
              <h2 className="font-semibold text-gray-900 flex items-center gap-2">
                <Clock className="w-4 h-4 text-brand-500" /> Riwayat Status
              </h2>
            </div>
            <div className="card-body">
              {fkp.status_logs.length === 0 ? (
                <p className="text-sm text-gray-400 text-center py-4">Belum ada riwayat.</p>
              ) : (
                <ol className="relative border-l border-gray-100 space-y-4 ml-2">
                  {[...fkp.status_logs].reverse().map((log) => (
                    <li key={log.id} className="pl-4">
                      <div className="absolute -left-1.5 w-3 h-3 rounded-full border-2 border-white bg-brand-400" />
                      <p className="text-xs text-gray-400">{formatDateTime(log.changed_at)}</p>
                      <p className="text-sm font-medium text-gray-800 mt-0.5">
                        {log.status_lama
                          ? `${FKP_STATUS_LABEL[log.status_lama as FkpStatusKey] ?? log.status_lama} → `
                          : ''}
                        <span className="text-brand-600">
                          {FKP_STATUS_LABEL[log.status_baru as FkpStatusKey] ?? log.status_baru}
                        </span>
                      </p>
                      {log.catatan && (
                        <p className="text-xs text-gray-500 mt-1 bg-gray-50 rounded px-2 py-1">
                          {log.catatan}
                        </p>
                      )}
                    </li>
                  ))}
                </ol>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ════════════════════════════════════════════════════════════════════ */}
      {/* MODALS                                                              */}
      {/* ════════════════════════════════════════════════════════════════════ */}

      {/* Modal generik: catatan saja */}
      {(['apsm_review', 'admin_approve', 'rsm_approve', 'direktur_approve',
        'final_accept', 'close'] as ModalTipe[]).includes(modal!) && (
        <Modal isOpen={!!modal} onClose={closeModal}
          title={MODAL_TITLES[modal!]} size="sm">
          <div className="space-y-4">
            <Textarea label="Catatan (opsional)"
              placeholder="Tambahkan catatan untuk aksi ini..."
              value={catatan} onChange={(e) => setCatatan(e.target.value)} rows={4} />
            <ModalFooter onCancel={closeModal} onConfirm={handleConfirm}
              isLoading={isConfirming} confirmLabel="Konfirmasi" />
          </div>
        </Modal>
      )}

      {/* Modal minta revisi / reject — catatan wajib */}
      {(['revision', 'reject', 'final_reject'] as ModalTipe[]).includes(modal!) && (
        <Modal isOpen={!!modal} onClose={closeModal}
          title={MODAL_TITLES[modal!]} size="sm">
          <div className="space-y-4">
            <Textarea label="Alasan (wajib)" required
              placeholder="Jelaskan alasan penolakan atau revisi..."
              value={catatan} onChange={(e) => setCatatan(e.target.value)} rows={4} />
            <ModalFooter onCancel={closeModal} onConfirm={handleConfirm}
              isLoading={isConfirming} confirmLabel="Konfirmasi"
              confirmClassName="btn-danger" />
          </div>
        </Modal>
      )}

      {/* Modal mulai investigasi — konfirmasi saja */}
      <Modal isOpen={modal === 'investigate'} onClose={closeModal}
        title="Mulai Investigasi" size="sm">
        <div className="space-y-4">
          <p className="text-sm text-gray-600">
            Anda akan memulai investigasi untuk FKP{' '}
            <span className="font-mono font-semibold">{fkp.nomor_fkp}</span>.
            Status akan berubah menjadi <strong>Investigasi</strong>.
          </p>
          <ModalFooter onCancel={closeModal} onConfirm={handleConfirm}
            isLoading={isConfirming} confirmLabel="Mulai Investigasi" />
        </div>
      </Modal>

      {/* Modal selesaikan investigasi — pilih sumber + catatan */}
      <Modal isOpen={modal === 'finish_investigation'} onClose={closeModal}
        title="Selesaikan Investigasi" size="sm">
        <div className="space-y-4">
          <Select label="Sumber Ketidaksesuaian" required
            value={sumber} onChange={(e) => setSumber(e.target.value as 'internal' | 'pelanggan')}>
            <option value="internal">✅ Internal — cacat dari produksi (keluhan valid)</option>
            <option value="pelanggan">❌ Pelanggan — bukan cacat produksi (ditolak)</option>
          </Select>
          <Textarea label="Catatan QC (opsional)"
            placeholder="Temuan investigasi, kondisi produk, dll..."
            value={catatan} onChange={(e) => setCatatan(e.target.value)} rows={4} />
          <ModalFooter onCancel={closeModal} onConfirm={handleConfirm}
            isLoading={isConfirming} confirmLabel="Simpan Hasil Investigasi" />
        </div>
      </Modal>

      {/* Modal buat resolusi */}
      <Modal isOpen={modal === 'resolusi'} onClose={closeModal}
        title="Buat Resolusi" size="md">
        <div className="space-y-4">
          <Select label="Tipe Resolusi" required
            value={tipeResolusi} onChange={(e) => setTipeResolusi(e.target.value)}>
            <option value="tukar_barang">Tukar Barang (DO)</option>
            <option value="potong_tagihan">Potong Tagihan / Cashback</option>
            <option value="pemusnahan">Pemusnahan</option>
          </Select>

          {tipeResolusi === 'potong_tagihan' && (
            <>
              <Input label="Nilai Cashback (Rp)" type="number" required
                value={resolusiData.nilai_cashback}
                onChange={(e) => setResolusiData(p => ({ ...p, nilai_cashback: e.target.value }))} />
              <div className="grid grid-cols-2 gap-3">
                <Input label="Nama Bank" required
                  value={resolusiData.nama_bank}
                  onChange={(e) => setResolusiData(p => ({ ...p, nama_bank: e.target.value }))} />
                <Input label="No. Rekening" required
                  value={resolusiData.nomor_rekening}
                  onChange={(e) => setResolusiData(p => ({ ...p, nomor_rekening: e.target.value }))} />
              </div>
              <Input label="Atas Nama" required
                value={resolusiData.atas_nama}
                onChange={(e) => setResolusiData(p => ({ ...p, atas_nama: e.target.value }))} />
              <Input label="Nomor Nota Retur"
                value={resolusiData.nomor_nota_retur}
                onChange={(e) => setResolusiData(p => ({ ...p, nomor_nota_retur: e.target.value }))} />
            </>
          )}

          {tipeResolusi === 'tukar_barang' && (
            <>
              <Input label="Nomor DO" required
                value={resolusiData.nomor_do}
                onChange={(e) => setResolusiData(p => ({ ...p, nomor_do: e.target.value }))} />
              <div className="grid grid-cols-2 gap-3">
                <Input label="Ekspedisi"
                  value={resolusiData.ekspedisi}
                  onChange={(e) => setResolusiData(p => ({ ...p, ekspedisi: e.target.value }))} />
                <Input label="No. Resi"
                  value={resolusiData.resi_pengiriman}
                  onChange={(e) => setResolusiData(p => ({ ...p, resi_pengiriman: e.target.value }))} />
              </div>
            </>
          )}

          {tipeResolusi === 'pemusnahan' && (
            <>
              <Input label="Tanggal Pemusnahan" type="date" required
                value={resolusiData.tanggal_pemusnahan}
                onChange={(e) => setResolusiData(p => ({ ...p, tanggal_pemusnahan: e.target.value }))} />
              <Input label="Lokasi Pemusnahan" required
                value={resolusiData.lokasi_pemusnahan}
                onChange={(e) => setResolusiData(p => ({ ...p, lokasi_pemusnahan: e.target.value }))} />
            </>
          )}

          <Textarea label="Keterangan Tambahan"
            value={resolusiData.keterangan}
            onChange={(e) => setResolusiData(p => ({ ...p, keterangan: e.target.value }))} rows={3} />

          <ModalFooter onCancel={closeModal} onConfirm={handleConfirm}
            isLoading={isConfirming} confirmLabel="Simpan Resolusi" />
        </div>
      </Modal>

    </div>
  )
}

// ─── Label modal ──────────────────────────────────────────────────────────────
const MODAL_TITLES: Partial<Record<ModalTipe, string>> = {
  apsm_review:          'Review & Teruskan ke Admin HO',
  admin_approve:        'ACC & Teruskan ke QC',
  revision:             'Minta Revisi',
  investigate:          'Mulai Investigasi',
  finish_investigation: 'Selesaikan Investigasi',
  rsm_approve:          'Approve & Teruskan ke Direktur',
  direktur_approve:     'Approve & Teruskan ke Admin HO',
  final_accept:         'Terima FKP',
  final_reject:         'Tolak FKP',
  reject:               'Tolak FKP',
  close:                'Tutup FKP',
  resolusi:             'Buat Resolusi',
}

// ─── Helper components ────────────────────────────────────────────────────────

function ModalFooter({
  onCancel,
  onConfirm,
  isLoading,
  confirmLabel = 'Konfirmasi',
  confirmClassName = 'btn-primary',
}: {
  onCancel: () => void
  onConfirm: () => void
  isLoading: boolean
  confirmLabel?: string
  confirmClassName?: string
}) {
  return (
    <div className="flex gap-2 justify-end pt-2">
      <button onClick={onCancel} className="btn-secondary" disabled={isLoading}>
        Batal
      </button>
      <button onClick={onConfirm} className={confirmClassName} disabled={isLoading}>
        {isLoading ? <><Loader2 className="w-4 h-4 animate-spin" /> Memproses...</> : confirmLabel}
      </button>
    </div>
  )
}

function InfoRow({
  label, value, className, mono,
}: {
  label: string
  value: string | number | null | undefined
  className?: string
  mono?: boolean
}) {
  return (
    <div>
      <dt className="text-xs font-medium text-gray-400">{label}</dt>
      <dd className={`text-sm text-gray-900 mt-0.5 ${mono ? 'font-mono' : ''} ${className ?? ''}`}>
        {value ?? '—'}
      </dd>
    </div>
  )
}

function CatatanItem({ label, value }: { label: string; value: string | null | undefined }) {
  if (!value) return null
  return (
    <div className="p-3 rounded-lg bg-gray-50 border border-gray-100">
      <p className="text-xs font-semibold text-gray-500 mb-1">{label}</p>
      <p className="text-sm text-gray-800 whitespace-pre-wrap">{value}</p>
    </div>
  )
}