import api from '@/lib/axios'
import type {
  FkpDetail,
  FkpListItem,
  FkpCreatePayload,
  StatusTransitionPayload,
  InvestigasiPayload,
  ResolusiPayload,
} from '@/types'


export const fkpApi = {
  // ── List & Detail ──────────────────────────────────────
  list: async (params?: { status?: string; prioritas?: string }): Promise<FkpListItem[]> => {
    const res = await api.get<FkpListItem[]>('/fkp/', { params })
    return res.data
  },

  detail: async (id: string): Promise<FkpDetail> => {
    const res = await api.get<FkpDetail>(`/fkp/${id}`)
    return res.data
  },

  // ── CRUD ───────────────────────────────────────────────
  create: async (data: FkpCreatePayload): Promise<FkpDetail> => {
    const res = await api.post<FkpDetail>('/fkp/', data)
    return res.data
  },

  update: async (id: string, data: Partial<FkpCreatePayload>): Promise<FkpDetail> => {
    const res = await api.put<FkpDetail>(`/fkp/${id}`, data)
    return res.data
  },

  // ── Upload ─────────────────────────────────────────────
  uploadAttachment: async (fkpId: string, file: File): Promise<unknown> => {
    const form = new FormData()
    form.append('file', file)
    const res = await api.post(`/fkp/${fkpId}/attachments`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    return res.data
  },

  deleteAttachment: async (fkpId: string, attachmentId: string): Promise<void> => {
    await api.delete(`/fkp/${fkpId}/attachments/${attachmentId}`)
  },

  // ── Transisi Status ────────────────────────────────────

  submit: async (id: string): Promise<FkpDetail> => {
    const res = await api.post<FkpDetail>(`/fkp/${id}/submit`)
    return res.data
  },

  apsmReview: (id: string, data: { catatan?: string | null }) =>
    api.post(`/fkp/${id}/apsm-review`, data).then((r) => r.data),

  adminApprove: (id: string, data: { catatan_admin?: string | null }) =>
    api.post(`/fkp/${id}/admin-approve`, data).then((r) => r.data),

  requestRevision: (id: string, data: { catatan: string }) =>
    api.post(`/fkp/${id}/revision`, data).then((r) => r.data),

  startInvestigation: async (id: string): Promise<FkpDetail> => {
    const res = await api.post<FkpDetail>(`/fkp/${id}/investigate`)
    return res.data
  },

  // Backend: data.sumber_ketidaksesuaian + data.catatan (body: InvestigasiRequest)
  finishInvestigation: (
    id: string,
    data: { sumber_ketidaksesuaian: 'internal' | 'pelanggan'; catatan?: string | null },
  ) =>
    api.post(`/fkp/${id}/finish-investigation`, data).then((r) => r.data),

  rsmApprove: (id: string, data: { catatan?: string | null }) =>
    api.post(`/fkp/${id}/rsm-approve`, data).then((r) => r.data),

  direkturApprove: (id: string, data: { catatan?: string | null }) =>
    api.post(`/fkp/${id}/direktur-approve`, data).then((r) => r.data),

  // Backend: terima dikirim sebagai query param, catatan di body
  finalDecision: (id: string, terima: boolean, data: { catatan?: string | null }) =>
    api
      .post(`/fkp/${id}/final-decision`, data, { params: { terima } })
      .then((r) => r.data),

  // Backend: POST /fkp/{id}/reject — body: StatusTransitionRequest { catatan }
  reject: (id: string, data: { catatan: string }) =>
    api.post(`/fkp/${id}/reject`, data).then((r) => r.data),

  // Backend: POST /fkp/{id}/close — body: StatusTransitionRequest { catatan? }
  close: (id: string, data: { catatan?: string | null }) =>
    api.post(`/fkp/${id}/close`, data).then((r) => r.data),

  // ── Resolusi ───────────────────────────────────────────

  createResolusi: (
    id: string,
    data: {
      tipe_resolusi: string
      nilai_cashback?: number | null
      nama_bank?: string | null
      nomor_rekening?: string | null
      atas_nama?: string | null
      nomor_nota_retur?: string | null
      nomor_do?: string | null
      ekspedisi?: string | null
      resi_pengiriman?: string | null
      tanggal_pemusnahan?: string | null
      lokasi_pemusnahan?: string | null
      keterangan?: string | null
    },
  ) =>
    api.post(`/fkp/${id}/resolution`, data).then((r) => r.data),

  // Backend: POST /fkp/{id}/surat-jalan — body: SuratJalanRequest { nomor_surat_jalan }
  inputSuratJalan: (id: string, nomor_surat_jalan: string) =>
    api.post(`/fkp/${id}/surat-jalan`, { nomor_surat_jalan }).then((r) => r.data),
}