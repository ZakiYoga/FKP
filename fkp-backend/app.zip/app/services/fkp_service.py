"""
FKP Service — state machine engine.

Alur status lengkap:
  draft
    → submitted                   (distributor/outlet/sc_spv/apsm)
    → apsm_reviewed               (apsm)           ← bisa minta revisi ke submitted
    → rsm_approval_investigasi    (admin_ho)        ← bisa minta revisi ke submitted
    → in_investigation            (rsm approve)     ← rsm bisa revisi ke apsm_reviewed
    → investigated                (qc)
    → rsm_approval_resolusi       (admin_ho)        ← rsm bisa revisi ke investigated
    → direktur_approval           (rsm approve)
    → accepted                    (direktur approve)
    → in_process                  (admin_ho — tukar_barang / potong_tagihan)
                                   atau langsung closed (pemusnahan)
    → closed                      (admin_ho)

  Need revision — mundur 1 langkah ke pihak yang bertanggung jawab:
    apsm_reviewed            → need_revision → kembali ke submitted
    rsm_approval_investigasi → need_revision → kembali ke submitted (Admin HO)
    rsm_approval_investigasi → kembali ke apsm_reviewed (RSM minta ke APSM)
    rsm_approval_resolusi    → need_revision → kembali ke investigated
"""
from unittest import result
from unittest import result
import uuid
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import HTTPException
from sqlmodel import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.fkp import (
    FkpComplaint, FkpItem, FkpStatus,
    FkpStatusLog, FkpResolution, FkpAttachment,
    FkpDocument,
)
from app.models.distributor import Distributor, DistributorUser
from app.models.outlet import Outlet
from app.models.sc_spv import ScSpvDistributor
from app.models.user import User
from app.schemas.fkp import (
    FkpCreate, FkpUpdate,
    FkpItemCreate, FkpItemUpdate,
    ApsmReviewRequest, AdminHoReviewRequest,
    RsmApproveRequest, DirekturApproveRequest,
    InvestigasiQcRequest, RejectRequest, RevisionRequest,
    UpdatePengirimanRequest,
)
from app.utils.fkp_number import generate_nomor_fkp
from app.services.notification_service import kirim_notifikasi_transisi



# ─── STATE MACHINE ────────────────────────────────────────────────────────────

VALID_TRANSITIONS = {
    FkpStatus.DRAFT:                    [FkpStatus.SUBMITTED],
    FkpStatus.SUBMITTED:                [FkpStatus.APSM_REVIEWED, FkpStatus.NEED_REVISION],
    FkpStatus.APSM_REVIEWED:            [
        FkpStatus.RSM_APPROVAL_INVESTIGASI,
        FkpStatus.NEED_REVISION,
        FkpStatus.REJECTED,
    ],
    FkpStatus.RSM_APPROVAL_INVESTIGASI: [
        FkpStatus.IN_INVESTIGATION,
        FkpStatus.NEED_REVISION,
        FkpStatus.APSM_REVIEWED,
        FkpStatus.REJECTED,
    ],
    FkpStatus.IN_INVESTIGATION:         [FkpStatus.INVESTIGATED],
    FkpStatus.INVESTIGATED:             [
        FkpStatus.RSM_APPROVAL_RESOLUSI,
        FkpStatus.REJECTED,
    ],
    FkpStatus.RSM_APPROVAL_RESOLUSI:    [
        FkpStatus.DIREKTUR_APPROVAL,
        FkpStatus.INVESTIGATED,
        FkpStatus.REJECTED,
    ],
    FkpStatus.DIREKTUR_APPROVAL:        [FkpStatus.ACCEPTED, FkpStatus.REJECTED],
    FkpStatus.ACCEPTED:                 [FkpStatus.IN_PROCESS, FkpStatus.CLOSED],
    FkpStatus.IN_PROCESS:               [FkpStatus.CLOSED],
    FkpStatus.NEED_REVISION:            [FkpStatus.SUBMITTED],
    FkpStatus.REJECTED:                 [],
    FkpStatus.CLOSED:                   [],
}

TRANSITION_ROLES = {
    FkpStatus.SUBMITTED:                ["outlet", "distributor", "sc_spv", "apsm", "superadmin"],
    FkpStatus.APSM_REVIEWED:            ["apsm", "superadmin"],
    FkpStatus.RSM_APPROVAL_INVESTIGASI: ["admin_ho", "superadmin"],
    FkpStatus.IN_INVESTIGATION:         ["rsm", "superadmin"],
    FkpStatus.INVESTIGATED:             ["qc", "superadmin"],
    FkpStatus.RSM_APPROVAL_RESOLUSI:    ["admin_ho", "superadmin"],
    FkpStatus.DIREKTUR_APPROVAL:        ["rsm", "superadmin"],
    FkpStatus.ACCEPTED:                 ["direktur", "superadmin"],
    FkpStatus.IN_PROCESS:               ["admin_ho", "superadmin"],
    FkpStatus.NEED_REVISION:            ["apsm", "admin_ho", "rsm", "superadmin"],
    FkpStatus.REJECTED:                 ["apsm", "admin_ho", "rsm", "direktur", "qc", "superadmin"],
    FkpStatus.CLOSED:                   ["admin_ho", "superadmin"],
}

# Format: { (status_asal, kode_role): status_tujuan }
REVISION_TARGETS = {
    (FkpStatus.SUBMITTED,                "apsm"):       FkpStatus.DRAFT,
    (FkpStatus.APSM_REVIEWED,            "apsm"):       FkpStatus.SUBMITTED,
    (FkpStatus.APSM_REVIEWED,            "superadmin"): FkpStatus.SUBMITTED,
    (FkpStatus.RSM_APPROVAL_INVESTIGASI, "admin_ho"):   FkpStatus.SUBMITTED,
    (FkpStatus.RSM_APPROVAL_INVESTIGASI, "rsm"):        FkpStatus.APSM_REVIEWED,
    (FkpStatus.RSM_APPROVAL_INVESTIGASI, "superadmin"): FkpStatus.SUBMITTED,
    (FkpStatus.RSM_APPROVAL_RESOLUSI,    "rsm"):        FkpStatus.INVESTIGATED,
    (FkpStatus.RSM_APPROVAL_RESOLUSI,    "admin_ho"):   FkpStatus.INVESTIGATED,
    (FkpStatus.RSM_APPROVAL_RESOLUSI,    "superadmin"): FkpStatus.INVESTIGATED,
}


# ─── HELPERS ──────────────────────────────────────────────────────────────────

async def _validate_transition(fkp: FkpComplaint, new_status: str, kode_role: str):
    allowed_next = VALID_TRANSITIONS.get(fkp.status, [])
    if new_status not in allowed_next:
        raise HTTPException(
            status_code=400,
            detail=f"Transisi dari '{fkp.status}' ke '{new_status}' tidak diizinkan.",
        )
    if kode_role not in TRANSITION_ROLES.get(new_status, []):
        raise HTTPException(
            status_code=403,
            detail=f"Role '{kode_role}' tidak bisa mengubah status ke '{new_status}'.",
        )


async def _log(db, fkp_id, status_lama, status_baru, changed_by, catatan=None):
    db.add(FkpStatusLog(
        fkp_id=fkp_id, status_lama=status_lama, status_baru=status_baru,
        catatan=catatan, changed_by=changed_by,
    ))


async def _get_or_404(fkp_id, db) -> FkpComplaint:
    r = await db.execute(select(FkpComplaint).where(FkpComplaint.id == fkp_id))
    fkp = r.scalar_one_or_none()
    if not fkp:
        raise HTTPException(status_code=404, detail="FKP tidak ditemukan.")
    return fkp


async def _load_fkp_detail(fkp_id, db) -> FkpComplaint:
    """Load FKP beserta semua relationships (eager load)."""
    r = await db.execute(
        select(FkpComplaint)
        .where(FkpComplaint.id == fkp_id)
        .options(
            selectinload(FkpComplaint.items),
            selectinload(FkpComplaint.distributor),
            selectinload(FkpComplaint.outlet),
            selectinload(FkpComplaint.status_logs),
            selectinload(FkpComplaint.resolution),
            selectinload(FkpComplaint.attachments),
            selectinload(FkpComplaint.documents),
        )
    )
    return r.scalar_one()

async def buat_dokumen(fkp_id: uuid.UUID, data, user, kode_role: str, db):
    """Admin HO / superadmin menambahkan dokumen formal ke FKP."""
    if kode_role not in ("admin_ho", "superadmin"):
        raise HTTPException(status_code=403, detail="Hanya Admin HO yang bisa menambah dokumen.")

    fkp = await _get_or_404(fkp_id, db)
    if fkp.status in FkpStatus.TERMINAL:
        raise HTTPException(
            status_code=400,
            detail=f"Dokumen tidak bisa ditambah ke FKP dengan status '{fkp.status}'.",
        )

    dokumen = FkpDocument(
        fkp_id=fkp_id,
        dibuat_oleh=user.id,
        **data.model_dump(exclude_none=True),
    )
    db.add(dokumen)
    await db.commit()
    await db.refresh(dokumen)
    return dokumen


async def hapus_dokumen(fkp_id: uuid.UUID, dokumen_id: uuid.UUID, user, kode_role: str, db):
    """Hapus dokumen — hanya oleh pembuatnya atau superadmin."""
    r = await db.execute(
        select(FkpDocument).where(
            FkpDocument.id == dokumen_id,
            FkpDocument.fkp_id == fkp_id,
        )
    )
    dokumen = r.scalar_one_or_none()
    if not dokumen:
        raise HTTPException(status_code=404, detail="Dokumen tidak ditemukan.")
    if kode_role != "superadmin" and dokumen.dibuat_oleh != user.id:
        raise HTTPException(status_code=403, detail="Hanya pembuat dokumen atau superadmin yang bisa menghapus.")

    await db.delete(dokumen)
    await db.commit()
    return {"detail": "Dokumen berhasil dihapus."}

# ─── LIST & DETAIL ────────────────────────────────────────────────────────────

async def list_fkp(db, user, kode_role, status_filter=None, prioritas_filter=None):
    query = select(FkpComplaint)

    if kode_role == "outlet":
        r = await db.execute(select(Outlet).where(Outlet.pic_user_id == user.id))
        outlet_ids = [o.id for o in r.scalars().all()]
        if not outlet_ids:
            return []
        query = query.where(FkpComplaint.outlet_id.in_(outlet_ids))

    elif kode_role == "distributor":
        r = await db.execute(select(DistributorUser).where(DistributorUser.user_id == user.id))
        dist_ids = [du.distributor_id for du in r.scalars().all()]
        if not dist_ids:
            return []
        query = query.where(FkpComplaint.distributor_id.in_(dist_ids))

    elif kode_role == "sc_spv":
        r = await db.execute(select(ScSpvDistributor).where(ScSpvDistributor.sc_spv_user_id == user.id))
        dist_ids = [sd.distributor_id for sd in r.scalars().all()]
        if not dist_ids:
            return []
        query = query.where(FkpComplaint.distributor_id.in_(dist_ids))

    elif kode_role == "apsm":
        from app.models.area import Area
        r = await db.execute(select(Area).where(Area.pic_user_id == user.id))
        area_ids = [a.id for a in r.scalars().all()]
        if not area_ids:
            return []
        r2 = await db.execute(select(Distributor).where(Distributor.area_id.in_(area_ids)))
        dist_ids = [d.id for d in r2.scalars().all()]
        if not dist_ids:
            return []
        query = query.where(FkpComplaint.distributor_id.in_(dist_ids))

    elif kode_role == "finance":
        r = await db.execute(
            select(FkpResolution.fkp_id).where(
                FkpResolution.tipe_resolusi == "potong_tagihan"
            )
        )
        fkp_ids = r.scalars().all()
        if not fkp_ids:
            return []
        query = query.where(FkpComplaint.id.in_(fkp_ids))

        # Guard: finance hanya boleh filter status yang relevan dengan tugasnya
        if status_filter and status_filter not in FkpStatus.FINANCE_VISIBLE:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Finance hanya bisa memfilter status: {FkpStatus.FINANCE_VISIBLE}. "
                    f"Status '{status_filter}' tidak relevan dengan role finance."
                ),
            )

    # rsm, direktur, qc, admin_ho, superadmin → semua FKP

    if status_filter:
        query = query.where(FkpComplaint.status == status_filter)
    if prioritas_filter:
        query = query.where(FkpComplaint.prioritas == prioritas_filter)

    result = await db.execute(
    query
    .options(
        selectinload(FkpComplaint.distributor),
        selectinload(FkpComplaint.outlet),
    )
    .order_by(FkpComplaint.created_at.desc())
)
    return result.scalars().all()

async def get_fkp_detail(fkp_id, db, user, kode_role):
    fkp = await _get_or_404(fkp_id, db)
    if kode_role == "outlet":
        r = await db.execute(select(Outlet).where(
            Outlet.pic_user_id == user.id,
            Outlet.distributor_id == fkp.distributor_id,
        ))
        if not r.scalar_one_or_none():
            raise HTTPException(status_code=403, detail="Akses ditolak.")
    elif kode_role == "distributor":
        r = await db.execute(select(DistributorUser).where(
            DistributorUser.user_id == user.id,
            DistributorUser.distributor_id == fkp.distributor_id,
        ))
        if not r.scalar_one_or_none():
            raise HTTPException(status_code=403, detail="Akses ditolak.")
    elif kode_role == "finance":
        # Finance hanya boleh akses FKP yang resolusinya potong_tagihan
        r = await db.execute(select(FkpResolution).where(
            FkpResolution.fkp_id == fkp.id,
            FkpResolution.tipe_resolusi == "potong_tagihan",
        ))
        if not r.scalar_one_or_none():
            raise HTTPException(
                status_code=403,
                detail="Akses ditolak. Finance hanya bisa mengakses FKP dengan resolusi potong_tagihan.",
            )
    return await _load_fkp_detail(fkp.id, db)


# ─── CRUD ─────────────────────────────────────────────────────────────────────

async def create_fkp(data: FkpCreate, user: User, kode_role: str, db) -> FkpComplaint:
    """Buat FKP baru dengan multi-item sekaligus."""
    if kode_role == "outlet":
        r = await db.execute(select(Outlet).where(
            Outlet.pic_user_id == user.id,
            Outlet.distributor_id == data.distributor_id,
        ))
        outlet_milik_user = r.scalar_one_or_none()
        if not outlet_milik_user:
            raise HTTPException(status_code=403, detail="Distributor tidak sesuai dengan outlet Anda.")
        if not data.outlet_id:
            data.outlet_id = outlet_milik_user.id

    elif kode_role == "distributor":
        r = await db.execute(select(DistributorUser).where(
            DistributorUser.user_id == user.id,
            DistributorUser.distributor_id == data.distributor_id,
        ))
        if not r.scalar_one_or_none():
            raise HTTPException(status_code=403, detail="Distributor bukan milik Anda.")

    elif kode_role == "sc_spv":
        r = await db.execute(select(ScSpvDistributor).where(
            ScSpvDistributor.sc_spv_user_id == user.id,
            ScSpvDistributor.distributor_id == data.distributor_id,
        ))
        if not r.scalar_one_or_none():
            raise HTTPException(status_code=403, detail="Distributor tidak dalam tanggungan Anda.")

    elif kode_role == "apsm":
        from app.models.area import Area
        r = await db.execute(select(Area).where(Area.pic_user_id == user.id))
        area_ids = [a.id for a in r.scalars().all()]
        r2 = await db.execute(select(Distributor).where(
            Distributor.id == data.distributor_id,
            Distributor.area_id.in_(area_ids),
        ))
        if not r2.scalar_one_or_none():
            raise HTTPException(status_code=403, detail="Distributor di luar area Anda.")

    # Validator Pydantic sudah pastikan items tidak kosong
    nomor_fkp = await generate_nomor_fkp(db)
    fkp = FkpComplaint(
        nomor_fkp=nomor_fkp,
        distributor_id=data.distributor_id,
        outlet_id=data.outlet_id,
        submitted_by=user.id,
        prioritas=data.prioritas,
        catatan_distributor=data.catatan_distributor,
        status=FkpStatus.DRAFT,
        lokasi_pembelian=data.lokasi_pembelian,
    )
    db.add(fkp)
    await db.flush()

    for item_data in data.items:
        item = FkpItem(
            fkp_id=fkp.id,
            **item_data.model_dump(exclude_none=True),
        )
        db.add(item)

    await _log(db, fkp.id, None, FkpStatus.DRAFT, user.id, "FKP dibuat")
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)


async def update_fkp(fkp_id, data: FkpUpdate, user, kode_role, db):
    """Update header FKP — hanya saat draft/need_revision."""
    fkp = await _get_or_404(fkp_id, db)
    if fkp.status not in FkpStatus.EDITABLE:
        raise HTTPException(status_code=400, detail=f"FKP status '{fkp.status}' tidak bisa diedit.")
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(fkp, k, v)
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await db.commit()
    return await _load_fkp_detail(fkp_id, db)


# ─── CRUD FKP ITEMS ───────────────────────────────────────────────────────────

async def add_fkp_item(fkp_id, item_data: dict, user, db) -> FkpItem:
    fkp = await _get_or_404(fkp_id, db)
    if fkp.status not in FkpStatus.EDITABLE:
        raise HTTPException(status_code=400, detail="Item hanya bisa ditambah saat status draft atau need_revision.")
    item = FkpItem(fkp_id=fkp_id, **item_data)
    db.add(item)
    await db.commit()
    await db.refresh(item)
    return item


async def update_fkp_item(fkp_id, item_id, data: FkpItemUpdate, user, db) -> FkpItem:
    fkp = await _get_or_404(fkp_id, db)
    if fkp.status not in FkpStatus.EDITABLE:
        raise HTTPException(status_code=400, detail="Item hanya bisa diedit saat status draft atau need_revision.")
    r = await db.execute(select(FkpItem).where(FkpItem.id == item_id, FkpItem.fkp_id == fkp_id))
    item = r.scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Item tidak ditemukan.")
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(item, k, v)
    item.updated_at = datetime.now(timezone.utc)
    db.add(item)
    await db.commit()
    await db.refresh(item)
    return item


async def delete_fkp_item(fkp_id, item_id, user, db):
    fkp = await _get_or_404(fkp_id, db)
    if fkp.status not in FkpStatus.EDITABLE:
        raise HTTPException(status_code=400, detail="Item hanya bisa dihapus saat status draft atau need_revision.")
    r = await db.execute(select(FkpItem).where(FkpItem.id == item_id, FkpItem.fkp_id == fkp_id))
    item = r.scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Item tidak ditemukan.")
    # Cek minimal 1 item
    r2 = await db.execute(select(FkpItem).where(FkpItem.fkp_id == fkp_id))
    if len(r2.scalars().all()) <= 1:
        raise HTTPException(status_code=400, detail="FKP harus memiliki minimal 1 item. Hapus FKP-nya jika tidak diperlukan.")
    await db.delete(item)
    await db.commit()
    return {"detail": "Item berhasil dihapus."}


# ─── TRANSISI STATUS ──────────────────────────────────────────────────────────

async def submit_fkp(fkp_id, user, kode_role, db):
    """Draft / Need Revision → Submitted."""
    fkp = await _get_or_404(fkp_id, db)
    await _validate_transition(fkp, FkpStatus.SUBMITTED, kode_role)

    r = await db.execute(select(FkpAttachment).where(FkpAttachment.fkp_id == fkp_id))
    if not r.scalars().first():
        raise HTTPException(status_code=400, detail="Minimal 1 foto bukti wajib diupload sebelum submit.")

    r2 = await db.execute(select(FkpItem).where(FkpItem.fkp_id == fkp_id))
    if not r2.scalars().first():
        raise HTTPException(status_code=400, detail="FKP harus memiliki minimal 1 item produk.")

    lama = fkp.status
    fkp.status = FkpStatus.SUBMITTED
    if lama == FkpStatus.DRAFT:
        fkp.tanggal_pengajuan = datetime.now(timezone.utc)
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await _log(db, fkp.id, lama, FkpStatus.SUBMITTED, user.id)
    await kirim_notifikasi_transisi(db, fkp, lama, FkpStatus.SUBMITTED, user)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)


async def apsm_review(fkp_id, data: ApsmReviewRequest, user, kode_role, db):
    """Submitted → Apsm Reviewed."""
    fkp = await _get_or_404(fkp_id, db)
    await _validate_transition(fkp, FkpStatus.APSM_REVIEWED, kode_role)

    # FIX: item_reviews sekarang List[ItemApsmReview] — akses via atribut, bukan dict.get()
    if data.item_reviews:
        for review in data.item_reviews:
            r = await db.execute(select(FkpItem).where(
                FkpItem.id == review.item_id,
                FkpItem.fkp_id == fkp_id,
            ))
            item = r.scalar_one_or_none()
            if item:
                if review.rekomendasi_apsm is not None:
                    item.rekomendasi_apsm = review.rekomendasi_apsm
                if review.catatan_apsm is not None:
                    item.catatan_apsm = review.catatan_apsm
                if review.persentase_disetujui_apsm is not None:
                    item.persentase_disetujui_apsm = review.persentase_disetujui_apsm
                item.updated_at = datetime.now(timezone.utc)
                db.add(item)

    lama = fkp.status
    fkp.status = FkpStatus.APSM_REVIEWED
    fkp.catatan_apsm = data.catatan_apsm
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await _log(db, fkp.id, lama, FkpStatus.APSM_REVIEWED, user.id, data.catatan_apsm)
    await kirim_notifikasi_transisi(db, fkp, lama, FkpStatus.APSM_REVIEWED, user)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)


async def admin_ho_review(fkp_id, data: AdminHoReviewRequest, user, kode_role, db):
    """Apsm Reviewed → Rsm Approval Investigasi."""
    fkp = await _get_or_404(fkp_id, db)
    await _validate_transition(fkp, FkpStatus.RSM_APPROVAL_INVESTIGASI, kode_role)

    # FIX: item_reviews sekarang List[ItemAdminHoReview]
    if data.item_reviews:
        for review in data.item_reviews:
            r = await db.execute(select(FkpItem).where(
                FkpItem.id == review.item_id,
                FkpItem.fkp_id == fkp_id,
            ))
            item = r.scalar_one_or_none()
            if item:
                if review.rekomendasi_admin_ho is not None:
                    item.rekomendasi_admin_ho = review.rekomendasi_admin_ho
                if review.catatan_admin_ho is not None:
                    item.catatan_admin_ho = review.catatan_admin_ho
                if review.persentase_disetujui_admin_ho is not None:
                    item.persentase_disetujui_admin_ho = review.persentase_disetujui_admin_ho
                item.updated_at = datetime.now(timezone.utc)
                db.add(item)

    lama = fkp.status
    fkp.status = FkpStatus.RSM_APPROVAL_INVESTIGASI
    fkp.catatan_admin = data.catatan_admin
    fkp.handled_by = user.id
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await _log(db, fkp.id, lama, FkpStatus.RSM_APPROVAL_INVESTIGASI, user.id, data.catatan_admin)
    await kirim_notifikasi_transisi(db, fkp, lama, FkpStatus.RSM_APPROVAL_INVESTIGASI, user)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)


async def rsm_approve_investigasi(fkp_id, data: RsmApproveRequest, user, kode_role, db):
    """RSM approve → In Investigation / tolak → Rejected."""
    fkp = await _get_or_404(fkp_id, db)
    new_status = FkpStatus.IN_INVESTIGATION if data.disetujui else FkpStatus.REJECTED
    await _validate_transition(fkp, new_status, kode_role)
    lama = fkp.status
    fkp.status = new_status
    fkp.catatan_rsm_investigasi = data.catatan
    if not data.disetujui:
        fkp.tanggal_selesai = datetime.now(timezone.utc)
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await _log(db, fkp.id, lama, new_status, user.id, data.catatan)
    await kirim_notifikasi_transisi(db, fkp, lama, new_status, user)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)


async def qc_investigasi(fkp_id, data: InvestigasiQcRequest, user, kode_role, db):
    """QC selesai investigasi → Investigated."""
    fkp = await _get_or_404(fkp_id, db)
    await _validate_transition(fkp, FkpStatus.INVESTIGATED, kode_role)

    # FIX: item_results sekarang List[ItemQcResult]
    if data.item_results:
        for result in data.item_results:
            r = await db.execute(select(FkpItem).where(
                FkpItem.id == result.item_id,
                FkpItem.fkp_id == fkp_id,
            ))
            item = r.scalar_one_or_none()
            if item:
                item.status_item = result.status_item
                if result.catatan_qc is not None:
                    item.catatan_qc = result.catatan_qc
                if result.alasan_penolakan is not None:
                    item.alasan_penolakan = result.alasan_penolakan
                item.updated_at = datetime.now(timezone.utc)
                db.add(item)

    lama = fkp.status
    fkp.status = FkpStatus.INVESTIGATED
    fkp.catatan_qc = data.catatan_qc
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await _log(db, fkp.id, lama, FkpStatus.INVESTIGATED, user.id,
               f"Sumber: {data.sumber_ketidaksesuaian}. {data.catatan_qc or ''}".strip())
    await kirim_notifikasi_transisi(db, fkp, lama, FkpStatus.INVESTIGATED, user)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)


async def admin_ho_request_resolusi_approval(fkp_id, catatan, user, kode_role, db):
    """Investigated → Rsm Approval Resolusi."""
    fkp = await _get_or_404(fkp_id, db)
    await _validate_transition(fkp, FkpStatus.RSM_APPROVAL_RESOLUSI, kode_role)
    lama = fkp.status
    fkp.status = FkpStatus.RSM_APPROVAL_RESOLUSI
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await _log(db, fkp.id, lama, FkpStatus.RSM_APPROVAL_RESOLUSI, user.id, catatan)
    await kirim_notifikasi_transisi(db, fkp, lama, FkpStatus.RSM_APPROVAL_RESOLUSI, user)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)


async def rsm_approve_resolusi(fkp_id, data: RsmApproveRequest, user, kode_role, db):
    """RSM approve → Direktur Approval / tolak → Rejected."""
    fkp = await _get_or_404(fkp_id, db)
    new_status = FkpStatus.DIREKTUR_APPROVAL if data.disetujui else FkpStatus.REJECTED
    await _validate_transition(fkp, new_status, kode_role)
    lama = fkp.status
    fkp.status = new_status
    fkp.catatan_rsm_resolusi = data.catatan
    if not data.disetujui:
        fkp.tanggal_selesai = datetime.now(timezone.utc)
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await _log(db, fkp.id, lama, new_status, user.id, data.catatan)
    await kirim_notifikasi_transisi(db, fkp, lama, new_status, user)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)


async def direktur_approve(fkp_id, data: DirekturApproveRequest, user, kode_role, db):
    """Direktur Approval → Accepted / Rejected."""
    fkp = await _get_or_404(fkp_id, db)
    new_status = FkpStatus.ACCEPTED if data.disetujui else FkpStatus.REJECTED
    await _validate_transition(fkp, new_status, kode_role)
    lama = fkp.status
    fkp.status = new_status
    fkp.catatan_direktur = data.catatan
    if not data.disetujui:
        fkp.tanggal_selesai = datetime.now(timezone.utc)
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await _log(db, fkp.id, lama, new_status, user.id, data.catatan)
    await kirim_notifikasi_transisi(db, fkp, lama, new_status, user)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)


async def update_pengiriman(fkp_id, data: UpdatePengirimanRequest, user, kode_role, db):
    """
    Accepted → In Process (tukar_barang / potong_tagihan)
             → Closed langsung (pemusnahan)
    """
    fkp = await _get_or_404(fkp_id, db)

    if fkp.status != FkpStatus.ACCEPTED:
        raise HTTPException(
            status_code=400,
            detail=f"Endpoint ini hanya bisa dipanggil saat status 'accepted'. Status saat ini: '{fkp.status}'."
        )
    if kode_role not in TRANSITION_ROLES[FkpStatus.IN_PROCESS]:
        raise HTTPException(status_code=403, detail=f"Role '{kode_role}' tidak diizinkan.")

    r = await db.execute(select(FkpResolution).where(FkpResolution.fkp_id == fkp_id))
    resolusi = r.scalar_one_or_none()
    if not resolusi:
        raise HTTPException(
            status_code=400,
            detail="Resolusi belum dibuat. Buat resolusi terlebih dahulu sebelum memproses pengiriman."
        )

    tipe = resolusi.tipe_resolusi
    lama = fkp.status

    if tipe == "tukar_barang":
        new_status = FkpStatus.IN_PROCESS
        if data.resi_pengiriman:
            resolusi.resi_pengiriman = data.resi_pengiriman
        if data.ekspedisi:
            resolusi.ekspedisi = data.ekspedisi
        db.add(resolusi)
        if data.nomor_surat_jalan:
            fkp.nomor_surat_jalan = data.nomor_surat_jalan
        log_catatan = f"Barang dikirim via {data.ekspedisi or resolusi.ekspedisi or '-'}. Resi: {data.resi_pengiriman or resolusi.resi_pengiriman or '-'}."

    elif tipe == "potong_tagihan":
        new_status = FkpStatus.IN_PROCESS
        log_catatan = data.catatan or "Proses potong tagihan dimulai."

    elif tipe == "pemusnahan":
        new_status = FkpStatus.CLOSED
        fkp.tanggal_selesai = datetime.now(timezone.utc)
        log_catatan = data.catatan or "Pemusnahan selesai. FKP ditutup."

    else:
        raise HTTPException(status_code=400, detail=f"tipe_resolusi '{tipe}' tidak dikenal.")

    fkp.status = new_status
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await _log(db, fkp.id, lama, new_status, user.id, log_catatan)
    await kirim_notifikasi_transisi(db, fkp, lama, new_status, user)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)


async def request_revision(fkp_id, data: RevisionRequest, user, kode_role, db):
    """Minta revisi — tujuan mundur ditentukan otomatis dari REVISION_TARGETS."""
    if not data.catatan:
        raise HTTPException(status_code=400, detail="Catatan alasan revisi wajib diisi.")
    fkp = await _get_or_404(fkp_id, db)

    target_status = REVISION_TARGETS.get((fkp.status, kode_role))
    if not target_status:
        raise HTTPException(
            status_code=400,
            detail=f"Role '{kode_role}' tidak bisa meminta revisi dari status '{fkp.status}'.",
        )

    lama = fkp.status
    fkp.status = target_status
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await _log(db, fkp.id, lama, target_status, user.id, data.catatan)
    await kirim_notifikasi_transisi(db, fkp, lama, target_status, user)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)


async def reject_fkp(fkp_id, data: RejectRequest, user, kode_role, db):
    """Tolak FKP dari status mana pun yang diizinkan."""
    if not data.catatan:
        raise HTTPException(status_code=400, detail="Alasan penolakan wajib diisi.")
    fkp = await _get_or_404(fkp_id, db)
    await _validate_transition(fkp, FkpStatus.REJECTED, kode_role)
    lama = fkp.status
    fkp.status = FkpStatus.REJECTED
    fkp.tanggal_selesai = datetime.now(timezone.utc)
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await _log(db, fkp.id, lama, FkpStatus.REJECTED, user.id, data.catatan)
    await kirim_notifikasi_transisi(db, fkp, lama, FkpStatus.REJECTED, user)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)


async def input_surat_jalan(fkp_id, nomor_surat_jalan, user, db):
    """Admin HO input/update nomor surat jalan kapan pun."""
    fkp = await _get_or_404(fkp_id, db)
    fkp.nomor_surat_jalan = nomor_surat_jalan
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await db.commit()
    return await _load_fkp_detail(fkp_id, db)


async def close_fkp(fkp_id, catatan, user, kode_role, db):
    """In Process → Closed."""
    fkp = await _get_or_404(fkp_id, db)

    if fkp.status != FkpStatus.IN_PROCESS:
        raise HTTPException(
            status_code=400,
            detail=(
                f"FKP tidak bisa ditutup dari status '{fkp.status}'. "
                f"Status harus 'in_process' sebelum bisa ditutup."
            )
        )

    await _validate_transition(fkp, FkpStatus.CLOSED, kode_role)
    lama = fkp.status
    fkp.status = FkpStatus.CLOSED
    fkp.tanggal_selesai = datetime.now(timezone.utc)
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await _log(db, fkp.id, lama, FkpStatus.CLOSED, user.id, catatan or "FKP ditutup.")
    await kirim_notifikasi_transisi(db, fkp, lama, FkpStatus.CLOSED, user)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)


async def buat_resolusi(fkp_id, data, user, kode_role, db):
    """
    Admin HO buat / update resolusi saat status 'investigated'.
    Setelah resolusi dibuat, Admin HO bisa langsung request ke RSM.
    Resolusi BISA diupdate selama belum closed/rejected.
    """
    from app.schemas.fkp import ResolusiCreate
    fkp = await _get_or_404(fkp_id, db)

    ALLOWED_STATUS = [
        FkpStatus.INVESTIGATED,
        FkpStatus.RSM_APPROVAL_RESOLUSI,
        FkpStatus.DIREKTUR_APPROVAL,
        FkpStatus.ACCEPTED,
    ]
    if fkp.status not in ALLOWED_STATUS:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Resolusi hanya bisa dibuat/diupdate saat status "
                f"'investigated', 'rsm_approval_resolusi', 'direktur_approval', atau 'accepted'. "
                f"Status saat ini: '{fkp.status}'."
            ),
        )
    if kode_role not in ["admin_ho", "superadmin"]:
        raise HTTPException(status_code=403, detail="Hanya Admin HO yang bisa membuat resolusi.")

    # Cek apakah sudah ada resolusi — jika ada, update; jika belum, buat baru
    r = await db.execute(select(FkpResolution).where(FkpResolution.fkp_id == fkp_id))
    resolusi = r.scalar_one_or_none()
    
    resolusi_data = data.model_dump(exclude_none=True)
 
    if resolusi:
        # Update resolusi yang sudah ada
        for k, v in resolusi_data.items():
            setattr(resolusi, k, v)
        db.add(resolusi)
    else:
        resolusi = FkpResolution(
            fkp_id=fkp_id,
            dibuat_oleh=user.id,
            **resolusi_data,
        )
        db.add(resolusi)
 
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)

async def proses_finance(
    fkp_id: uuid.UUID,
    catatan_finance: str | None,
    user,
    kode_role: str,
    db,
):
    """
    Role finance menandai FKP sudah diproses dari sisi keuangan.
    Berlaku untuk tipe resolusi potong_tagihan.
 
    Finance dapat:
    - Menuliskan catatan proses finance
    - Menandai sudah diproses (diproses_finance=True)
    - Upload bukti via endpoint attachment (tipe_dokumen=invoice_terpotong/bukti_transfer)
 
    Status FKP tidak berubah — ini hanya update di tabel resolusi.
    """
    from datetime import datetime, timezone
    from sqlalchemy import select as sa_select
    from app.models.fkp import FkpComplaint, FkpResolution, FkpStatus, TipeResolusi
 
    if kode_role not in ("finance", "admin_ho", "superadmin"):
        raise HTTPException(status_code=403, detail="Hanya role finance yang bisa memproses keuangan.")
 
    fkp = await _get_or_404(fkp_id, db)
 
    ALLOWED_STATUS = [FkpStatus.ACCEPTED, FkpStatus.IN_PROCESS]
    if fkp.status not in ALLOWED_STATUS:
        raise HTTPException(
            status_code=400,
            detail=f"Proses finance hanya bisa dilakukan saat status accepted/in_process. Status: '{fkp.status}'.",
        )
 
    # Cek resolusi ada
    r = await db.execute(sa_select(FkpResolution).where(FkpResolution.fkp_id == fkp_id))
    resolusi = r.scalar_one_or_none()
    if not resolusi:
        raise HTTPException(status_code=404, detail="Resolusi belum dibuat untuk FKP ini.")
 
    if resolusi.tipe_resolusi != TipeResolusi.POTONG_TAGIHAN:
        raise HTTPException(
            status_code=400,
            detail="Proses finance hanya berlaku untuk resolusi tipe 'potong_tagihan'.",
        )
 
    resolusi.catatan_finance         = catatan_finance
    resolusi.diproses_finance        = True
    resolusi.tanggal_proses_finance  = datetime.now(timezone.utc)
    resolusi.finance_user_id         = user.id
 
    db.add(resolusi)
    fkp.updated_at = datetime.now(timezone.utc)
    db.add(fkp)
    await db.commit()
    return await _load_fkp_detail(fkp.id, db)