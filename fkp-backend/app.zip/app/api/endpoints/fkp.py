"""
FKP Router — endpoint lengkap untuk semua operasi FKP.

FIX:
- Upload attachment sekarang menerima fkp_item_id opsional
- Schema sudah menggunakan typed Pydantic models (bukan dict)
- Endpoint item management ditambahkan (add/update/delete item)
"""
import uuid
from typing import Optional, List
from fastapi import APIRouter, Depends, UploadFile, File, Query, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db, get_current_user, get_kode_role
from app.models.user import User
from app.schemas.fkp import (
    FkpCreate, FkpUpdate, FkpDetailResponse, FkpListResponse,
    FkpItemCreate, FkpItemUpdate, FkpItemResponse,
    ApsmReviewRequest, AdminHoReviewRequest,
    RsmApproveRequest, DirekturApproveRequest,
    InvestigasiQcRequest, RejectRequest, RevisionRequest,
    UpdatePengirimanRequest, ResolusiCreate,
    SuratJalanRequest, AttachmentResponse,
    FkpDocumentCreate, FkpDocumentResponse
)
from app.services import fkp_service, upload_service
from app.services.fkp_service import (
    create_fkp, update_fkp, list_fkp, get_fkp_detail,
    submit_fkp, apsm_review, admin_ho_review,
    rsm_approve_investigasi, qc_investigasi,
    admin_ho_request_resolusi_approval, rsm_approve_resolusi,
    direktur_approve, update_pengiriman, request_revision,
    reject_fkp, input_surat_jalan, close_fkp,
    add_fkp_item, update_fkp_item, delete_fkp_item,
    buat_dokumen, hapus_dokumen
)

router = APIRouter()

@router.get("/meta/tipe-dokumen")
async def list_tipe_dokumen():
    """
    Listing semua tipe dokumen yang valid beserta label dan kelompoknya.
    Digunakan FE untuk membangun dropdown pilihan tipe_dokumen saat upload.
    """
    from app.models.fkp import TipeDokumen
    return {
        "tipe_dokumen": [
            # Keluhan & investigasi
            {"value": TipeDokumen.FOTO_KELUHAN,        "label": "Foto Keluhan Produk",         "kelompok": "keluhan"},
            {"value": TipeDokumen.FOTO_SAMPLE,         "label": "Foto Sample",                 "kelompok": "keluhan"},
            {"value": TipeDokumen.FOTO_INVESTIGASI,    "label": "Foto Hasil Investigasi",      "kelompok": "investigasi"},
            # Resolusi tukar barang
            {"value": TipeDokumen.SURAT_JALAN,         "label": "Surat Jalan",                 "kelompok": "resolusi"},
            {"value": TipeDokumen.FOTO_SERAH_TERIMA,   "label": "Foto Serah Terima Barang",    "kelompok": "resolusi"},
            {"value": TipeDokumen.BERITA_ACARA_PENUKARAN, "label": "Berita Acara Penukaran",  "kelompok": "resolusi"},
            # Resolusi potong tagihan
            {"value": TipeDokumen.INVOICE_TERPOTONG,   "label": "Invoice Terpotong",           "kelompok": "resolusi"},
            {"value": TipeDokumen.BUKTI_TRANSFER,      "label": "Bukti Transfer Cashback",     "kelompok": "resolusi"},
            {"value": TipeDokumen.NOTA_RETUR,          "label": "Nota Retur",                  "kelompok": "resolusi"},
            # Resolusi pemusnahan
            {"value": TipeDokumen.FOTO_PEMUSNAHAN,     "label": "Foto Pemusnahan",             "kelompok": "resolusi"},
            {"value": TipeDokumen.BERITA_ACARA_PEMUSNAHAN, "label": "Berita Acara Pemusnahan","kelompok": "resolusi"},
            # Dokumen umum
            {"value": TipeDokumen.BA_PEMERIKSAAN,      "label": "Berita Acara Pemeriksaan",   "kelompok": "dokumen"},
            {"value": TipeDokumen.SURAT_PERNYATAAN,    "label": "Surat Pernyataan",            "kelompok": "dokumen"},
            {"value": TipeDokumen.DOKUMEN_LAINNYA,     "label": "Dokumen Lainnya",             "kelompok": "dokumen"},
        ]
    }

# ─── FKP MASTER ───────────────────────────────────────────────────────────────

@router.get("", response_model=List[FkpListResponse])
async def get_list_fkp(
    status: Optional[str] = Query(None, description="Filter berdasarkan status FKP"),
    prioritas: Optional[str] = Query(None, description="Filter berdasarkan prioritas"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    Ambil daftar FKP. Otomatis difilter berdasarkan role:
    - outlet/distributor/sc_spv/apsm → hanya FKP area mereka
    - rsm/admin_ho/qc/direktur/superadmin → semua FKP
    """
    return await list_fkp(db, user, kode_role, status, prioritas)


@router.post("", response_model=FkpDetailResponse, status_code=201)
async def buat_fkp(
    data: FkpCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    Buat FKP baru dengan multi-item sekaligus.
    Minimal 1 item produk wajib disertakan.
    """
    return await create_fkp(data, user, kode_role, db)


@router.get("/{fkp_id}", response_model=FkpDetailResponse)
async def detail_fkp(
    fkp_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """Ambil detail lengkap FKP termasuk semua items, status logs, dan resolusi."""
    return await get_fkp_detail(fkp_id, db, user, kode_role)


@router.patch("/{fkp_id}", response_model=FkpDetailResponse)
async def edit_fkp(
    fkp_id: uuid.UUID,
    data: FkpUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """Update header FKP (prioritas, catatan, outlet). Hanya saat status draft/need_revision."""
    return await update_fkp(fkp_id, data, user, kode_role, db)


# ─── FKP ITEMS ────────────────────────────────────────────────────────────────

@router.post("/{fkp_id}/items", response_model=FkpItemResponse, status_code=201)
async def tambah_item(
    fkp_id: uuid.UUID,
    data: FkpItemCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    Tambah item produk baru ke FKP yang sudah ada.
    Hanya bisa saat status draft atau need_revision.
    """
    return await add_fkp_item(fkp_id, data.model_dump(exclude_none=True), user, db)


@router.patch("/{fkp_id}/items/{item_id}", response_model=FkpItemResponse)
async def edit_item(
    fkp_id: uuid.UUID,
    item_id: uuid.UUID,
    data: FkpItemUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    Edit item produk di dalam FKP.
    Hanya bisa saat status draft atau need_revision.
    """
    return await update_fkp_item(fkp_id, item_id, data, user, db)


@router.delete("/{fkp_id}/items/{item_id}")
async def hapus_item(
    fkp_id: uuid.UUID,
    item_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    Hapus item dari FKP. Minimal 1 item harus tetap ada.
    Hanya bisa saat status draft atau need_revision.
    """
    return await delete_fkp_item(fkp_id, item_id, user, db)


# ─── TRANSISI STATUS ──────────────────────────────────────────────────────────

@router.post("/{fkp_id}/submit", response_model=FkpDetailResponse)
async def submit(
    fkp_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """Submit FKP dari status draft/need_revision ke submitted."""
    return await submit_fkp(fkp_id, user, kode_role, db)


@router.post("/{fkp_id}/apsm-review", response_model=FkpDetailResponse)
async def review_apsm(
    fkp_id: uuid.UUID,
    data: ApsmReviewRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    APSM submit review + rekomendasi per item.
    Status: submitted → apsm_reviewed.
    """
    return await apsm_review(fkp_id, data, user, kode_role, db)


@router.post("/{fkp_id}/admin-ho-review", response_model=FkpDetailResponse)
async def review_admin_ho(
    fkp_id: uuid.UUID,
    data: AdminHoReviewRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    Admin HO review + rekomendasi per item, meneruskan ke RSM.
    Status: apsm_reviewed → rsm_approval_investigasi.
    """
    return await admin_ho_review(fkp_id, data, user, kode_role, db)


@router.post("/{fkp_id}/rsm-approve-investigasi", response_model=FkpDetailResponse)
async def rsm_approve_inv(
    fkp_id: uuid.UUID,
    data: RsmApproveRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    RSM approve/tolak investigasi.
    Approve → in_investigation. Tolak → rejected.
    """
    return await rsm_approve_investigasi(fkp_id, data, user, kode_role, db)


@router.post("/{fkp_id}/qc-investigasi", response_model=FkpDetailResponse)
async def investigasi_qc(
    fkp_id: uuid.UUID,
    data: InvestigasiQcRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    QC mengisi hasil investigasi per item.
    Status: in_investigation → investigated.
    """
    return await qc_investigasi(fkp_id, data, user, kode_role, db)


@router.post("/{fkp_id}/request-resolusi-approval", response_model=FkpDetailResponse)
async def request_resolusi_approval(
    fkp_id: uuid.UUID,
    catatan: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    Admin HO meminta persetujuan resolusi ke RSM.
    Status: investigated → rsm_approval_resolusi.
    """
    return await admin_ho_request_resolusi_approval(fkp_id, catatan, user, kode_role, db)


@router.post("/{fkp_id}/rsm-approve-resolusi", response_model=FkpDetailResponse)
async def rsm_approve_res(
    fkp_id: uuid.UUID,
    data: RsmApproveRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    RSM approve/tolak resolusi.
    Approve → direktur_approval. Tolak → rejected.
    """
    return await rsm_approve_resolusi(fkp_id, data, user, kode_role, db)


@router.post("/{fkp_id}/direktur-approve", response_model=FkpDetailResponse)
async def approve_direktur(
    fkp_id: uuid.UUID,
    data: DirekturApproveRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    Direktur approve/tolak FKP.
    Approve → accepted. Tolak → rejected.
    """
    return await direktur_approve(fkp_id, data, user, kode_role, db)


@router.post("/{fkp_id}/update-pengiriman", response_model=FkpDetailResponse)
async def proses_pengiriman(
    fkp_id: uuid.UUID,
    data: UpdatePengirimanRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    Admin HO memproses pengiriman atau potong tagihan.
    - tukar_barang/potong_tagihan: accepted → in_process
    - pemusnahan: accepted → closed langsung
    """
    return await update_pengiriman(fkp_id, data, user, kode_role, db)


@router.post("/{fkp_id}/close", response_model=FkpDetailResponse)
async def tutup_fkp(
    fkp_id: uuid.UUID,
    catatan: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """Tutup FKP setelah resolusi selesai. Status: in_process → closed."""
    return await close_fkp(fkp_id, catatan, user, kode_role, db)


@router.post("/{fkp_id}/request-revision", response_model=FkpDetailResponse)
async def minta_revisi(
    fkp_id: uuid.UUID,
    data: RevisionRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    Minta revisi. Target status mundur ditentukan otomatis berdasarkan role dan status saat ini.
    Catatan wajib diisi sebagai alasan.
    """
    return await request_revision(fkp_id, data, user, kode_role, db)


@router.post("/{fkp_id}/reject", response_model=FkpDetailResponse)
async def tolak_fkp(
    fkp_id: uuid.UUID,
    data: RejectRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """Tolak FKP. Status → rejected. Alasan penolakan wajib diisi."""
    return await reject_fkp(fkp_id, data, user, kode_role, db)


# ─── RESOLUSI ─────────────────────────────────────────────────────────────────

@router.post("/{fkp_id}/resolusi", response_model=FkpDetailResponse, status_code=201)
async def buat_resolusi(
    fkp_id: uuid.UUID,
    data: ResolusiCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    Admin HO membuat resolusi setelah FKP diterima direktur (status: accepted).
    Tipe: tukar_barang, potong_tagihan, atau pemusnahan.
    """
    return await fkp_service.buat_resolusi(fkp_id, data, user, kode_role, db)


@router.patch("/{fkp_id}/surat-jalan", response_model=FkpDetailResponse)
async def update_surat_jalan(
    fkp_id: uuid.UUID,
    data: SuratJalanRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """Input/update nomor surat jalan untuk resolusi tukar_barang."""
    return await input_surat_jalan(fkp_id, data.nomor_surat_jalan, user, db)


# ─── UPLOAD ATTACHMENT ────────────────────────────────────────────────────────

@router.post("/{fkp_id}/attachments", response_model=AttachmentResponse, status_code=201)
async def upload_bukti(
    fkp_id: uuid.UUID,
    file: UploadFile = File(...),
    fkp_item_id: Optional[uuid.UUID] = Query(
        None,
        description=(
            "UUID item produk. Jika diisi, foto dikaitkan ke item tertentu. "
            "Jika kosong, foto level FKP secara keseluruhan."
        ),
    ),
    tipe_dokumen: Optional[str] = Query(
        None,
        description="Tipe dokumen dari TipeDokumen.ALL. Default: foto_keluhan.",
    ),
    keterangan: Optional[str] = Query(  
        None,
        description="Deskripsi singkat file, misal 'Invoice INV-2025-001'.",
    ),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    Upload foto/video bukti keluhan.

    - Tanpa fkp_item_id → foto umum level FKP
    - Dengan fkp_item_id → foto spesifik untuk satu item produk

    Format yang didukung: JPEG, PNG, WebP, MP4, MOV.
    """
    return await upload_service.upload_attachment(fkp_id, file, user, db, fkp_item_id, tipe_dokumen, keterangan)


@router.delete("/{fkp_id}/attachments/{attachment_id}")
async def hapus_attachment(
    fkp_id: uuid.UUID,
    attachment_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """Hapus file bukti. Hanya bisa oleh uploader atau superadmin."""
    return await upload_service.delete_attachment(attachment_id, user, kode_role, db)

@router.post("/{fkp_id}/finance/proses", response_model=FkpDetailResponse)
async def proses_finance(
    fkp_id: uuid.UUID,
    catatan: Optional[str] = Query(default=None, description="Catatan proses finance"),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
    db: AsyncSession = Depends(get_db),
):
    """
    Role finance: tandai FKP potong_tagihan sudah diproses dari sisi keuangan.
    Upload bukti (invoice/transfer) via endpoint attachment terpisah.
    """
    return await fkp_service.proses_finance(fkp_id, catatan, user, kode_role, db)
 
@router.post("/{fkp_id}/documents", response_model=FkpDocumentResponse, status_code=201)
async def tambah_dokumen(
    fkp_id: uuid.UUID,
    data: FkpDocumentCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """
    Admin HO menambahkan dokumen formal ke FKP (BA, surat jalan, invoice, dsb).
    url_file diisi dengan URL hasil upload terpisah via storage service.
    """
    return await buat_dokumen(fkp_id, data, user, kode_role, db)


@router.delete("/{fkp_id}/documents/{dokumen_id}")
async def hapus_dokumen_fkp(
    fkp_id: uuid.UUID,
    dokumen_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    kode_role: str = Depends(get_kode_role),
):
    """Hapus dokumen dari FKP. Hanya oleh pembuat atau superadmin."""
    return await hapus_dokumen(fkp_id, dokumen_id, user, kode_role, db)